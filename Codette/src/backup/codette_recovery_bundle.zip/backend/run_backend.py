#!/usr/bin/env python3
"""
Backend Runner - Start the Codette AI Backend
"""

import asyncio
import logging
import sys
import os

# Add backend directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import app
import uvicorn

if __name__ == "__main__":
    print("🚀 Starting Codette AI Backend...")
    print("📚 Based on research papers by Jonathan Harrison (Raiff's Bits)")
    print("🧠 Real AI systems: DreamCore, Nexus, Aegis Council, Quantum Optimizer")
    print("="*60)
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )