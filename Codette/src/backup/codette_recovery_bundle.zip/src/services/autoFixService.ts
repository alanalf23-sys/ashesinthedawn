// Auto-Fix Service - Comprehensive Error Resolution System
import { aiCodeService } from './aiCodeService';
import { securityService } from './securityService';
import { errorControlService } from './errorControlService';

export interface AutoFixResult {
  fixed: boolean;
  original_code: string;
  fixed_code: string;
  fixes_applied: string[];
  confidence: number;
  manual_review_needed: boolean;
  explanation: string;
}

export interface FixRule {
  id: string;
  name: string;
  pattern: RegExp | string;
  replacement: string | ((match: string) => string);
  confidence: number;
  category: 'syntax' | 'security' | 'performance' | 'style' | 'accessibility';
  description: string;
  auto_applicable: boolean;
}

class AutoFixService {
  private fixRules: FixRule[] = [];
  private fixHistory: Array<{
    timestamp: Date;
    original: string;
    fixed: string;
    rules_applied: string[];
    success: boolean;
  }> = [];
  private isProcessing = false;
  private processingQueue: Array<() => Promise<void>> = [];

  constructor() {
    this.initializeFixRules();
  }

  private initializeFixRules(): void {
    this.fixRules = [
      // Syntax Fixes
      {
        id: 'missing-semicolon',
        name: 'Add Missing Semicolons',
        pattern: /(\w+)\s*$/gm,
        replacement: (match) => match.includes(';') ? match : `${match};`,
        confidence: 0.95,
        category: 'syntax',
        description: 'Adds missing semicolons at end of statements',
        auto_applicable: true
      },
      {
        id: 'fix-function-typo',
        name: 'Fix Function Typos',
        pattern: /\bfucntion\b/g,
        replacement: 'function',
        confidence: 0.99,
        category: 'syntax',
        description: 'Fixes common function keyword typos',
        auto_applicable: true
      },
      {
        id: 'fix-return-typo',
        name: 'Fix Return Typos',
        pattern: /\bretrun\b/g,
        replacement: 'return',
        confidence: 0.99,
        category: 'syntax',
        description: 'Fixes common return keyword typos',
        auto_applicable: true
      },
      {
        id: 'fix-console-typo',
        name: 'Fix Console Typos',
        pattern: /\bconsoel\b/g,
        replacement: 'console',
        confidence: 0.99,
        category: 'syntax',
        description: 'Fixes console object typos',
        auto_applicable: true
      },
      {
        id: 'fix-document-typo',
        name: 'Fix Document Typos',
        pattern: /\bdocumnet\b/g,
        replacement: 'document',
        confidence: 0.99,
        category: 'syntax',
        description: 'Fixes document object typos',
        auto_applicable: true
      },
      {
        id: 'fix-length-typo',
        name: 'Fix Length Typos',
        pattern: /\blenght\b/g,
        replacement: 'length',
        confidence: 0.99,
        category: 'syntax',
        description: 'Fixes length property typos',
        auto_applicable: true
      },

      // Security Fixes
      {
        id: 'replace-innerHTML',
        name: 'Replace Unsafe innerHTML',
        pattern: /(\w+)\.innerHTML\s*=\s*([^;]+);?/g,
        replacement: '$1.textContent = $2; // Auto-fixed: Changed innerHTML to textContent for security',
        confidence: 0.85,
        category: 'security',
        description: 'Replaces unsafe innerHTML with textContent',
        auto_applicable: true
      },
      {
        id: 'remove-eval',
        name: 'Remove Eval Usage',
        pattern: /eval\s*\([^)]+\);?/g,
        replacement: '// Auto-fixed: Removed unsafe eval() call',
        confidence: 0.7,
        category: 'security',
        description: 'Removes dangerous eval() calls',
        auto_applicable: false // Requires manual review
      },
      {
        id: 'fix-document-write',
        name: 'Remove Document.write',
        pattern: /document\.write\s*\([^)]+\);?/g,
        replacement: '// Auto-fixed: Removed unsafe document.write',
        confidence: 0.8,
        category: 'security',
        description: 'Removes unsafe document.write calls',
        auto_applicable: true
      },

      // Performance Fixes
      {
        id: 'optimize-array-operations',
        name: 'Optimize Array Operations',
        pattern: /(\w+)\.find\([^)]+\)[\s\S]*?\1\.filter\([^)]+\)/g,
        replacement: (match) => `// Auto-optimized: Consider using reduce() for single-pass processing\n${match}`,
        confidence: 0.6,
        category: 'performance',
        description: 'Suggests optimization for multiple array operations',
        auto_applicable: false
      },
      {
        id: 'add-react-memo',
        name: 'Add React.memo',
        pattern: /export\s+function\s+(\w+)\s*\(/g,
        replacement: 'export const $1 = React.memo(function $1(',
        confidence: 0.7,
        category: 'performance',
        description: 'Wraps components with React.memo for performance',
        auto_applicable: false
      },

      // Style Fixes
      {
        id: 'fix-var-usage',
        name: 'Replace var with const/let',
        pattern: /\bvar\s+(\w+)/g,
        replacement: 'const $1',
        confidence: 0.8,
        category: 'style',
        description: 'Replaces var with const for better scoping',
        auto_applicable: true
      },
      {
        id: 'add-strict-equality',
        name: 'Use Strict Equality',
        pattern: /(\w+)\s*==\s*([^=])/g,
        replacement: '$1 === $2',
        confidence: 0.9,
        category: 'style',
        description: 'Replaces == with === for strict equality',
        auto_applicable: true
      },

      // Accessibility Fixes
      {
        id: 'add-alt-text',
        name: 'Add Alt Text to Images',
        pattern: /<img\s+([^>]*?)src="([^"]*)"([^>]*?)(?!.*alt=)>/g,
        replacement: '<img $1src="$2"$3 alt="Image description needed">',
        confidence: 0.7,
        category: 'accessibility',
        description: 'Adds alt attributes to images without them',
        auto_applicable: true
      },
      {
        id: 'add-aria-labels',
        name: 'Add ARIA Labels to Buttons',
        pattern: /<button\s+([^>]*?)(?!.*aria-label=)>/g,
        replacement: '<button $1aria-label="Button action">',
        confidence: 0.6,
        category: 'accessibility',
        description: 'Adds ARIA labels to buttons without them',
        auto_applicable: false
      }
    ];
  }

  // Main auto-fix method
  async autoFix(
    code: string,
    language: string,
    options: {
      categories?: string[];
      confidence_threshold?: number;
      auto_apply_only?: boolean;
      max_fixes?: number;
      non_blocking?: boolean;
    } = {}
  ): Promise<AutoFixResult> {
    const {
      categories = ['syntax', 'security', 'style'],
      confidence_threshold = 0.8,
      auto_apply_only = true,
      max_fixes = 20,
      non_blocking = true
    } = options;

    // Non-blocking execution - queue if already processing
    if (non_blocking && this.isProcessing) {
      return new Promise((resolve) => {
        this.processingQueue.push(async () => {
          const result = await this.autoFix(code, language, { ...options, non_blocking: false });
          resolve(result);
        });
      });
    }

    this.isProcessing = true;

    try {
      let fixedCode = code;
      const appliedFixes: string[] = [];
      let totalConfidence = 0;
      let manualReviewNeeded = false;

      // Filter applicable rules
      const applicableRules = this.fixRules.filter(rule => 
        categories.includes(rule.category) &&
        rule.confidence >= confidence_threshold &&
        (!auto_apply_only || rule.auto_applicable)
      );

      // Apply fixes in order of confidence
      const sortedRules = applicableRules.sort((a, b) => b.confidence - a.confidence);

      for (const rule of sortedRules.slice(0, max_fixes)) {
        const beforeFix = fixedCode;
        
        try {
          if (typeof rule.pattern === 'string') {
            if (fixedCode.includes(rule.pattern)) {
              fixedCode = fixedCode.replace(new RegExp(rule.pattern, 'g'), rule.replacement as string);
            }
          } else {
            fixedCode = fixedCode.replace(rule.pattern, rule.replacement as string);
          }

          if (beforeFix !== fixedCode) {
            appliedFixes.push(rule.name);
            totalConfidence += rule.confidence;
            
            if (!rule.auto_applicable) {
              manualReviewNeeded = true;
            }
          }
        } catch (error) {
          console.warn(`Failed to apply fix rule ${rule.id}:`, error);
        }
      }

      // Additional AI-powered fixes
      if (language === 'typescript' || language === 'javascript') {
        const aiFixResult = await this.applyAIFixes(fixedCode, language);
        if (aiFixResult.fixed) {
          fixedCode = aiFixResult.code;
          appliedFixes.push(...aiFixResult.fixes);
        }
      }

      // Security auto-fixes
      const securityFixResult = await securityService.autoFixSecurityIssues(fixedCode);
      if (securityFixResult.fixesApplied.length > 0) {
        fixedCode = securityFixResult.fixedCode;
        appliedFixes.push(...securityFixResult.fixesApplied);
      }

      const avgConfidence = appliedFixes.length > 0 ? totalConfidence / appliedFixes.length : 0;
      const wasFixed = fixedCode !== code;

      // Record fix attempt
      this.fixHistory.push({
        timestamp: new Date(),
        original: code,
        fixed: fixedCode,
        rules_applied: appliedFixes,
        success: wasFixed
      });

      return {
        fixed: wasFixed,
        original_code: code,
        fixed_code: fixedCode,
        fixes_applied: appliedFixes,
        confidence: avgConfidence,
        manual_review_needed: manualReviewNeeded,
        explanation: this.generateFixExplanation(appliedFixes, avgConfidence)
      };

    } catch (error) {
      console.error('Auto-fix failed:', error);
      return {
        fixed: false,
        original_code: code,
        fixed_code: code,
        fixes_applied: [],
        confidence: 0,
        manual_review_needed: true,
        explanation: `Auto-fix failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    } finally {
      this.isProcessing = false;
      
      // Process next item in queue
      if (this.processingQueue.length > 0) {
        const nextTask = this.processingQueue.shift();
        if (nextTask) {
          setTimeout(() => nextTask(), 0); // Non-blocking execution
        }
      }
    }
  }

  // AI-powered intelligent fixes
  private async applyAIFixes(code: string, language: string): Promise<{
    fixed: boolean;
    code: string;
    fixes: string[];
  }> {
    try {
      const suggestions = await aiCodeService.getCodeOptimization(code, language);
      
      if (suggestions.length > 0 && suggestions[0].confidence > 0.8) {
        return {
          fixed: true,
          code: suggestions[0].text,
          fixes: ['AI-powered code optimization']
        };
      }
      
      return { fixed: false, code, fixes: [] };
    } catch (error) {
      console.warn('AI fixes failed:', error);
      return { fixed: false, code, fixes: [] };
    }
  }

  // Real-time auto-fix monitoring
  startAutoFixMonitoring(
    getCode: () => string,
    getLanguage: () => string,
    onAutoFix: (result: AutoFixResult) => void
  ): () => void {
    let isRunning = true;
    
    const interval = setInterval(async () => {
      if (!isRunning) return;
      
      try {
        const code = getCode();
        const language = getLanguage();
        
        // Only run if code exists and we're not already processing
        if (code.trim() && !this.isProcessing) {
          const result = await this.autoFix(code, language, {
            categories: ['syntax', 'security'],
            confidence_threshold: 0.95, // Higher threshold for auto-apply
            auto_apply_only: true,
            max_fixes: 3, // Limit fixes to prevent disruption
            non_blocking: true
          });
          
          // Only apply if very safe and non-disruptive
          if (result.fixed && result.confidence > 0.95 && result.fixes_applied.length <= 2) {
            onAutoFix(result);
          }
        }
      } catch (error) {
        // Silently handle errors to not disrupt user
        console.debug('Auto-fix monitoring error (non-critical):', error);
      }
    }, 10000); // Check every 10 seconds (less frequent)

    return () => {
      isRunning = false;
      clearInterval(interval);
    };
  }

  // Batch fix multiple files
  async batchAutoFix(
    files: Array<{ content: string; language: string; name: string }>,
    options: any = {}
  ): Promise<Array<AutoFixResult & { fileName: string }>> {
    const results: Array<AutoFixResult & { fileName: string }> = [];
    
    for (const file of files) {
      try {
        const result = await this.autoFix(file.content, file.language, options);
        results.push({ ...result, fileName: file.name });
      } catch (error) {
        console.error(`Batch fix failed for ${file.name}:`, error);
        results.push({
          fixed: false,
          original_code: file.content,
          fixed_code: file.content,
          fixes_applied: [],
          confidence: 0,
          manual_review_needed: true,
          explanation: `Fix failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
          fileName: file.name
        });
      }
    }
    
    return results;
  }

  // Generate comprehensive fix report
  generateFixReport(results: AutoFixResult[]): string {
    const totalFixes = results.reduce((sum, r) => sum + r.fixes_applied.length, 0);
    const successfulFixes = results.filter(r => r.fixed).length;
    const avgConfidence = results.reduce((sum, r) => sum + r.confidence, 0) / results.length;

    return `
# Auto-Fix Report
Generated: ${new Date().toLocaleString()}

## Summary
- Total fixes applied: ${totalFixes}
- Successful operations: ${successfulFixes}/${results.length}
- Average confidence: ${(avgConfidence * 100).toFixed(0)}%

## Fixes Applied
${results.map(result => `
### ${result.fixes_applied.length > 0 ? '✅' : '❌'} Fix Result
- Fixes: ${result.fixes_applied.join(', ') || 'None'}
- Confidence: ${(result.confidence * 100).toFixed(0)}%
- Manual review needed: ${result.manual_review_needed ? 'Yes' : 'No'}
- Explanation: ${result.explanation}
`).join('\n')}

## Recommendations
${this.generateRecommendations(results).map(rec => `- ${rec}`).join('\n')}
    `.trim();
  }

  private generateFixExplanation(fixes: string[], confidence: number): string {
    if (fixes.length === 0) {
      return 'No fixes were applied. Code appears to be in good condition.';
    }

    const explanations = [
      `Applied ${fixes.length} automatic fix${fixes.length !== 1 ? 'es' : ''}`,
      `Confidence level: ${(confidence * 100).toFixed(0)}%`,
      `Fixes included: ${fixes.join(', ')}`
    ];

    if (confidence < 0.7) {
      explanations.push('⚠️ Low confidence fixes - manual review recommended');
    } else if (confidence > 0.9) {
      explanations.push('✅ High confidence fixes - safe to apply');
    }

    return explanations.join('. ');
  }

  private generateRecommendations(results: AutoFixResult[]): string[] {
    const recommendations: string[] = [];
    
    const needsManualReview = results.filter(r => r.manual_review_needed).length;
    if (needsManualReview > 0) {
      recommendations.push(`${needsManualReview} result(s) need manual review`);
    }

    const lowConfidence = results.filter(r => r.confidence < 0.7).length;
    if (lowConfidence > 0) {
      recommendations.push(`${lowConfidence} fix(es) have low confidence - verify before applying`);
    }

    const securityFixes = results.filter(r => 
      r.fixes_applied.some(fix => fix.toLowerCase().includes('security'))
    ).length;
    if (securityFixes > 0) {
      recommendations.push(`${securityFixes} security fix(es) applied - test thoroughly`);
    }

    if (recommendations.length === 0) {
      recommendations.push('All fixes applied successfully with high confidence');
    }

    return recommendations;
  }

  // Get fix statistics
  getFixStatistics(): {
    total_fixes: number;
    success_rate: number;
    most_common_fix: string;
    avg_confidence: number;
  } {
    const totalAttempts = this.fixHistory.length;
    const successfulFixes = this.fixHistory.filter(f => f.success).length;
    const allFixes = this.fixHistory.flatMap(f => f.rules_applied);
    
    const fixCounts = allFixes.reduce((acc, fix) => {
      acc[fix] = (acc[fix] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const mostCommonFix = Object.entries(fixCounts)
      .sort(([,a], [,b]) => b - a)[0]?.[0] || 'None';

    const avgConfidence = this.fixHistory.length > 0 
      ? this.fixHistory.reduce((sum, f) => sum + (f.success ? 1 : 0), 0) / this.fixHistory.length
      : 0;

    return {
      total_fixes: allFixes.length,
      success_rate: totalAttempts > 0 ? successfulFixes / totalAttempts : 0,
      most_common_fix: mostCommonFix,
      avg_confidence: avgConfidence
    };
  }

  // Add custom fix rule
  addCustomFixRule(rule: FixRule): void {
    this.fixRules.push(rule);
  }

  // Get available fix categories
  getFixCategories(): string[] {
    return [...new Set(this.fixRules.map(rule => rule.category))];
  }

  // Clear fix history
  clearFixHistory(): void {
    this.fixHistory = [];
  }
}

export const autoFixService = new AutoFixService();