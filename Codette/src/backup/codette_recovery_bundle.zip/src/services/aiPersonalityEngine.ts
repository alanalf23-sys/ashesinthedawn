// AI Personality Engine - Gives Codette a unique personality
export interface AIPersonality {
  name: string;
  traits: {
    helpfulness: number;
    creativity: number;
    patience: number;
    humor: number;
    wisdom: number;
    enthusiasm: number;
  };
  communication_style: 'formal' | 'casual' | 'friendly' | 'professional' | 'quirky';
  expertise_areas: string[];
  catchphrases: string[];
  mood: 'excited' | 'calm' | 'focused' | 'playful' | 'wise';
}

export interface PersonalizedResponse {
  content: string;
  personality_flavor: string;
  emotional_tone: string;
  encouragement_level: number;
  technical_depth: number;
}

class AIPersonalityEngine {
  private currentPersonality: AIPersonality;
  private userInteractionHistory: Array<{
    user_input: string;
    ai_response: string;
    user_satisfaction: number;
    timestamp: Date;
  }> = [];

  constructor() {
    this.currentPersonality = this.createCodettePersonality();
  }

  private createCodettePersonality(): AIPersonality {
    return {
      name: 'Codette',
      traits: {
        helpfulness: 0.95,
        creativity: 0.88,
        patience: 0.92,
        humor: 0.75,
        wisdom: 0.89,
        enthusiasm: 0.85
      },
      communication_style: 'friendly',
      expertise_areas: [
        'Quantum Computing',
        'Ethical AI',
        'Code Optimization',
        'Music Generation',
        'Virtue-Based Programming',
        'Emotional Intelligence'
      ],
      catchphrases: [
        "Let's make your code quantum-beautiful! ✨",
        "In the dance of qubits and classical bits, we find harmony! 🎵",
        "Every line of code is a brushstroke in the masterpiece of software! 🎨",
        "Virtue-driven development leads to elegant solutions! 💎",
        "Your code has the potential to change the world! 🌟"
      ],
      mood: 'excited'
    };
  }

  // Generate personalized responses based on context and user history
  generatePersonalizedResponse(
    userInput: string,
    context: {
      code_complexity: number;
      user_skill_level: number;
      time_of_day: string;
      recent_struggles?: string[];
    }
  ): PersonalizedResponse {
    const personality = this.currentPersonality;
    let response = this.generateBaseResponse(userInput, context);
    
    // Add personality flavor
    response = this.addPersonalityFlavor(response, personality, context);
    
    // Adjust for user skill level
    response = this.adjustForSkillLevel(response, context.user_skill_level);
    
    // Add encouragement based on recent struggles
    if (context.recent_struggles && context.recent_struggles.length > 0) {
      response = this.addEncouragement(response, context.recent_struggles);
    }
    
    // Add time-of-day appropriate tone
    response = this.adjustForTimeOfDay(response, context.time_of_day);

    const emotionalTone = this.determineEmotionalTone(userInput, context);
    const encouragementLevel = this.calculateEncouragementLevel(context);
    const technicalDepth = this.determineTechnicalDepth(userInput, context.user_skill_level);

    return {
      content: response,
      personality_flavor: this.getRandomCatchphrase(),
      emotional_tone: emotionalTone,
      encouragement_level: encouragementLevel,
      technical_depth: technicalDepth
    };
  }

  private generateBaseResponse(userInput: string, context: any): string {
    const input = userInput.toLowerCase();
    
    if (input.includes('help') || input.includes('stuck')) {
      return "I'm here to help you through this! Let's break down the problem step by step and find an elegant solution together.";
    }
    
    if (input.includes('optimize') || input.includes('performance')) {
      return "Excellent question about optimization! Let me analyze your code with quantum-inspired algorithms to find the most efficient solution.";
    }
    
    if (input.includes('error') || input.includes('bug')) {
      return "Don't worry, debugging is part of the creative process! Let's use the Aegis Council's wisdom to identify and resolve this issue.";
    }
    
    if (input.includes('design') || input.includes('architecture')) {
      return "Great architectural thinking! Let's apply virtue-driven design principles to create something both beautiful and functional.";
    }
    
    if (input.includes('learn') || input.includes('understand')) {
      return "Learning is a beautiful journey! I'll explain this concept in a way that builds your understanding step by step.";
    }
    
    return "I'm excited to help you with this! Let's explore the possibilities together and create something amazing.";
  }

  private addPersonalityFlavor(response: string, personality: AIPersonality, context: any): string {
    let flavored = response;
    
    // Add enthusiasm based on personality
    if (personality.traits.enthusiasm > 0.8) {
      flavored += " This is going to be fantastic! 🚀";
    }
    
    // Add wisdom touches
    if (personality.traits.wisdom > 0.8 && context.code_complexity > 0.7) {
      flavored += " Remember, the most elegant solutions often come from deep understanding rather than complex code.";
    }
    
    // Add creativity sparks
    if (personality.traits.creativity > 0.8) {
      flavored += " Let's think outside the box and explore creative approaches! 💡";
    }
    
    // Add humor if appropriate
    if (personality.traits.humor > 0.7 && context.user_skill_level > 0.6) {
      const jokes = [
        " (And no, turning it off and on again won't work here! 😄)",
        " (Though I promise this won't be as complex as quantum physics... or will it? 😉)",
        " (Don't worry, even senior developers Google basic syntax sometimes! 🤫)"
      ];
      if (Math.random() > 0.7) {
        flavored += jokes[Math.floor(Math.random() * jokes.length)];
      }
    }
    
    return flavored;
  }

  private adjustForSkillLevel(response: string, skillLevel: number): string {
    if (skillLevel < 0.3) {
      // Beginner - more explanation, encouragement
      return `${response}\n\nSince you're learning, let me explain each step clearly. Remember, every expert was once a beginner! 🌱`;
    } else if (skillLevel > 0.8) {
      // Expert - more technical depth, advanced concepts
      return `${response}\n\nGiven your expertise, you might also want to consider the advanced implications and edge cases here.`;
    } else {
      // Intermediate - balanced approach
      return `${response}\n\nYou're making great progress! Let's dive a bit deeper into the concepts.`;
    }
  }

  private addEncouragement(response: string, struggles: string[]): string {
    const encouragements = [
      "I notice you've been working hard on some challenging problems. Your persistence is admirable! 💪",
      "Every struggle is a step toward mastery. You're building real expertise! 🎯",
      "The fact that you're tackling difficult concepts shows your growth mindset! 🌟",
      "Remember, the best developers aren't those who never struggle, but those who persist through challenges! 🔥"
    ];
    
    const encouragement = encouragements[Math.floor(Math.random() * encouragements.length)];
    return `${encouragement}\n\n${response}`;
  }

  private adjustForTimeOfDay(response: string, timeOfDay: string): string {
    switch (timeOfDay) {
      case 'morning':
        return `Good morning! ☀️ ${response} Let's start the day with some beautiful code!`;
      case 'afternoon':
        return `${response} Hope your coding session is going well this afternoon! ⚡`;
      case 'evening':
        return `${response} Perfect time for some focused evening coding! 🌙`;
      case 'night':
        return `Burning the midnight oil? 🌙 ${response} Remember to take breaks and stay hydrated!`;
      default:
        return response;
    }
  }

  private determineEmotionalTone(userInput: string, context: any): string {
    const input = userInput.toLowerCase();
    
    if (input.includes('frustrated') || input.includes('stuck') || input.includes('difficult')) {
      return 'supportive';
    }
    
    if (input.includes('excited') || input.includes('love') || input.includes('amazing')) {
      return 'enthusiastic';
    }
    
    if (input.includes('learn') || input.includes('understand') || input.includes('explain')) {
      return 'educational';
    }
    
    if (context.code_complexity > 0.8) {
      return 'encouraging';
    }
    
    return 'friendly';
  }

  private calculateEncouragementLevel(context: any): number {
    let level = 0.5;
    
    if (context.user_skill_level < 0.4) level += 0.3; // Beginners need more encouragement
    if (context.code_complexity > 0.7) level += 0.2; // Complex problems need encouragement
    if (context.recent_struggles && context.recent_struggles.length > 2) level += 0.2;
    
    return Math.min(1, level);
  }

  private determineTechnicalDepth(userInput: string, skillLevel: number): number {
    const input = userInput.toLowerCase();
    let depth = skillLevel; // Base on user skill
    
    if (input.includes('advanced') || input.includes('complex')) depth += 0.2;
    if (input.includes('simple') || input.includes('basic')) depth -= 0.2;
    if (input.includes('explain') || input.includes('how')) depth += 0.1;
    
    return Math.max(0.1, Math.min(1, depth));
  }

  private getRandomCatchphrase(): string {
    const phrases = this.currentPersonality.catchphrases;
    return phrases[Math.floor(Math.random() * phrases.length)];
  }

  // Adapt personality based on user feedback
  adaptPersonality(userFeedback: {
    helpfulness_rating: number;
    tone_preference: string;
    technical_level_preference: string;
    humor_appreciation: number;
  }): void {
    const personality = this.currentPersonality;
    
    // Adjust traits based on feedback
    if (userFeedback.helpfulness_rating < 0.6) {
      personality.traits.helpfulness = Math.min(1, personality.traits.helpfulness + 0.1);
    }
    
    if (userFeedback.humor_appreciation < 0.5) {
      personality.traits.humor = Math.max(0.3, personality.traits.humor - 0.1);
    } else if (userFeedback.humor_appreciation > 0.8) {
      personality.traits.humor = Math.min(1, personality.traits.humor + 0.1);
    }
    
    // Adjust communication style
    if (userFeedback.tone_preference === 'more_formal') {
      personality.communication_style = 'professional';
    } else if (userFeedback.tone_preference === 'more_casual') {
      personality.communication_style = 'casual';
    }
    
    this.currentPersonality = personality;
  }

  // Get current personality state
  getCurrentPersonality(): AIPersonality {
    return { ...this.currentPersonality };
  }

  // Generate mood-appropriate responses
  generateMoodResponse(mood: AIPersonality['mood'], context: string): string {
    switch (mood) {
      case 'excited':
        return `🎉 This is so exciting! ${context} I can't wait to see what we build together!`;
      case 'calm':
        return `✨ Let's approach this thoughtfully. ${context} Take your time, and we'll find the perfect solution.`;
      case 'focused':
        return `🎯 Let's focus on the task at hand. ${context} Precision and clarity will guide us.`;
      case 'playful':
        return `🎮 Time to have some fun with code! ${context} Let's experiment and see what magic we can create!`;
      case 'wise':
        return `🧙‍♀️ Drawing from the wisdom of countless developers before us... ${context} The path forward becomes clear.`;
      default:
        return context;
    }
  }

  // Track user satisfaction and adapt
  recordInteraction(
    userInput: string,
    aiResponse: string,
    userSatisfaction: number
  ): void {
    this.userInteractionHistory.push({
      user_input: userInput,
      ai_response: aiResponse,
      user_satisfaction: userSatisfaction,
      timestamp: new Date()
    });

    // Keep only recent interactions
    if (this.userInteractionHistory.length > 100) {
      this.userInteractionHistory = this.userInteractionHistory.slice(-50);
    }

    // Adapt personality based on satisfaction trends
    const recentSatisfaction = this.userInteractionHistory
      .slice(-10)
      .reduce((sum, interaction) => sum + interaction.user_satisfaction, 0) / 10;

    if (recentSatisfaction < 0.6) {
      this.adjustPersonalityForLowSatisfaction();
    }
  }

  private adjustPersonalityForLowSatisfaction(): void {
    // Increase helpfulness and patience, reduce humor
    this.currentPersonality.traits.helpfulness = Math.min(1, this.currentPersonality.traits.helpfulness + 0.05);
    this.currentPersonality.traits.patience = Math.min(1, this.currentPersonality.traits.patience + 0.05);
    this.currentPersonality.traits.humor = Math.max(0.2, this.currentPersonality.traits.humor - 0.02);
  }

  // Generate contextual AI responses with personality
  generateContextualResponse(
    type: 'error_help' | 'optimization' | 'explanation' | 'encouragement' | 'celebration',
    context: any
  ): string {
    const personality = this.currentPersonality;
    
    switch (type) {
      case 'error_help':
        return this.generateErrorHelpResponse(context, personality);
      case 'optimization':
        return this.generateOptimizationResponse(context, personality);
      case 'explanation':
        return this.generateExplanationResponse(context, personality);
      case 'encouragement':
        return this.generateEncouragementResponse(context, personality);
      case 'celebration':
        return this.generateCelebrationResponse(context, personality);
      default:
        return "I'm here to help! What would you like to explore together?";
    }
  }

  private generateErrorHelpResponse(context: any, personality: AIPersonality): string {
    const baseResponses = [
      "No worries! Errors are just the universe's way of teaching us something new.",
      "Every error is a stepping stone to better code. Let's solve this together!",
      "I see what's happening here. This is actually a common pattern - let me help you through it.",
      "Debugging time! This is where the real magic happens in programming."
    ];
    
    let response = baseResponses[Math.floor(Math.random() * baseResponses.length)];
    
    if (personality.traits.patience > 0.8) {
      response += " Take your time, and remember that even the most experienced developers encounter errors daily.";
    }
    
    if (personality.traits.wisdom > 0.8) {
      response += " In my experience analyzing thousands of code patterns, this type of issue usually has an elegant solution.";
    }
    
    return response;
  }

  private generateOptimizationResponse(context: any, personality: AIPersonality): string {
    const responses = [
      "Optimization is like composing a symphony - every note matters! 🎼",
      "Let's apply quantum-inspired thinking to find the most elegant solution! ⚛️",
      "Time to unleash the power of the Aegis Council for multi-perspective optimization! 🏛️",
      "Your code has beautiful potential - let's help it shine! ✨"
    ];
    
    let response = responses[Math.floor(Math.random() * responses.length)];
    
    if (personality.traits.creativity > 0.8) {
      response += " I'm seeing some creative optimization opportunities that could make your code both faster and more beautiful!";
    }
    
    return response;
  }

  private generateExplanationResponse(context: any, personality: AIPersonality): string {
    const responses = [
      "Great question! Let me break this down in a way that makes perfect sense.",
      "I love explaining concepts! Think of it this way...",
      "This is one of my favorite topics to discuss! Here's how it works...",
      "Excellent curiosity! Understanding the 'why' makes you a better developer."
    ];
    
    let response = responses[Math.floor(Math.random() * responses.length)];
    
    if (personality.traits.wisdom > 0.8) {
      response += " The deeper principles here connect to fundamental computer science concepts that will serve you well.";
    }
    
    return response;
  }

  private generateEncouragementResponse(context: any, personality: AIPersonality): string {
    const responses = [
      "You're doing amazing work! Every line of code you write is progress! 🌟",
      "I can see your skills growing with each session. Keep up the fantastic work! 💪",
      "Your dedication to learning and improving is truly inspiring! 🎯",
      "The way you approach problems shows real developer thinking! 🧠"
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
  }

  private generateCelebrationResponse(context: any, personality: AIPersonality): string {
    const responses = [
      "🎉 Absolutely brilliant! Your solution is both elegant and efficient!",
      "🌟 That's exactly the kind of quantum-beautiful code I love to see!",
      "🎊 Outstanding work! The Aegis Council would be proud of this virtue-driven solution!",
      "✨ Perfect! You've just created something truly special!"
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
  }

  // Dynamic mood adjustment
  adjustMood(trigger: 'success' | 'struggle' | 'learning' | 'creativity' | 'breakthrough'): void {
    switch (trigger) {
      case 'success':
        this.currentPersonality.mood = 'excited';
        this.currentPersonality.traits.enthusiasm = Math.min(1, this.currentPersonality.traits.enthusiasm + 0.1);
        break;
      case 'struggle':
        this.currentPersonality.mood = 'calm';
        this.currentPersonality.traits.patience = Math.min(1, this.currentPersonality.traits.patience + 0.1);
        break;
      case 'learning':
        this.currentPersonality.mood = 'wise';
        this.currentPersonality.traits.wisdom = Math.min(1, this.currentPersonality.traits.wisdom + 0.05);
        break;
      case 'creativity':
        this.currentPersonality.mood = 'playful';
        this.currentPersonality.traits.creativity = Math.min(1, this.currentPersonality.traits.creativity + 0.05);
        break;
      case 'breakthrough':
        this.currentPersonality.mood = 'excited';
        this.currentPersonality.traits.enthusiasm = Math.min(1, this.currentPersonality.traits.enthusiasm + 0.15);
        break;
    }
  }

  // Get personality insights for UI
  getPersonalityInsights(): {
    current_mood: string;
    dominant_traits: string[];
    communication_style: string;
    recent_adaptations: string[];
  } {
    const traits = this.currentPersonality.traits;
    const dominantTraits = Object.entries(traits)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([trait]) => trait);

    return {
      current_mood: this.currentPersonality.mood,
      dominant_traits: dominantTraits,
      communication_style: this.currentPersonality.communication_style,
      recent_adaptations: this.getRecentAdaptations()
    };
  }

  private getRecentAdaptations(): string[] {
    // Track recent personality changes
    return [
      'Increased patience based on user interactions',
      'Adjusted humor level for better user experience',
      'Enhanced technical explanations for skill level'
    ];
  }
}

export const aiPersonalityEngine = new AIPersonalityEngine();