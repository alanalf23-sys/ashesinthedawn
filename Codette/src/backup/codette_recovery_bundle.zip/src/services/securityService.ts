// Security Service - Comprehensive User Protection
export interface SecurityThreat {
  id: string;
  type: 'xss' | 'injection' | 'malicious_code' | 'data_leak' | 'unsafe_eval' | 'prototype_pollution';
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  location: string;
  recommendation: string;
  auto_fixable: boolean;
}

export interface SecurityScan {
  scan_id: string;
  timestamp: Date;
  threats_found: SecurityThreat[];
  security_score: number;
  recommendations: string[];
  safe_to_execute: boolean;
}

export interface UserSafetySettings {
  enable_code_scanning: boolean;
  block_malicious_patterns: boolean;
  require_confirmation_for_risky_operations: boolean;
  enable_privacy_protection: boolean;
  log_security_events: boolean;
  auto_fix_security_issues: boolean;
}

class SecurityService {
  private safetySettings: UserSafetySettings = {
    enable_code_scanning: true,
    block_malicious_patterns: true,
    require_confirmation_for_risky_operations: true,
    enable_privacy_protection: true,
    log_security_events: true,
    auto_fix_security_issues: true
  };

  private securityLog: Array<{
    timestamp: Date;
    event: string;
    severity: string;
    details: any;
  }> = [];

  // Comprehensive security scan of user code
  async scanCodeSecurity(code: string, language: string): Promise<SecurityScan> {
    const threats: SecurityThreat[] = [];
    
    // XSS Protection
    const xssThreats = this.detectXSSVulnerabilities(code);
    threats.push(...xssThreats);
    
    // Injection Protection
    const injectionThreats = this.detectInjectionVulnerabilities(code);
    threats.push(...injectionThreats);
    
    // Malicious Code Detection
    const maliciousThreats = this.detectMaliciousPatterns(code);
    threats.push(...maliciousThreats);
    
    // Data Leak Detection
    const dataLeakThreats = this.detectDataLeaks(code);
    threats.push(...dataLeakThreats);
    
    // Unsafe Evaluation
    const evalThreats = this.detectUnsafeEval(code);
    threats.push(...evalThreats);
    
    // Prototype Pollution
    const pollutionThreats = this.detectPrototypePollution(code);
    threats.push(...pollutionThreats);

    const securityScore = this.calculateSecurityScore(threats);
    const recommendations = this.generateSecurityRecommendations(threats);
    const safeToExecute = threats.filter(t => t.severity === 'critical' || t.severity === 'high').length === 0;

    const scan: SecurityScan = {
      scan_id: `scan_${Date.now()}`,
      timestamp: new Date(),
      threats_found: threats,
      security_score: securityScore,
      recommendations,
      safe_to_execute: safeToExecute
    };

    // Log security scan
    this.logSecurityEvent('security_scan', 'info', {
      threats_count: threats.length,
      security_score: securityScore,
      safe_to_execute: safeToExecute
    });

    return scan;
  }

  private detectXSSVulnerabilities(code: string): SecurityThreat[] {
    const threats: SecurityThreat[] = [];
    
    // Dangerous innerHTML usage
    if (code.includes('innerHTML') && !code.includes('sanitize')) {
      threats.push({
        id: 'xss_innerHTML',
        type: 'xss',
        severity: 'high',
        description: 'Unsafe innerHTML usage detected - potential XSS vulnerability',
        location: 'innerHTML assignment',
        recommendation: 'Use textContent or sanitize HTML content before assignment',
        auto_fixable: true
      });
    }
    
    // Dangerous dangerouslySetInnerHTML
    if (code.includes('dangerouslySetInnerHTML')) {
      threats.push({
        id: 'xss_dangerous_html',
        type: 'xss',
        severity: 'critical',
        description: 'dangerouslySetInnerHTML usage detected - high XSS risk',
        location: 'React dangerouslySetInnerHTML',
        recommendation: 'Sanitize HTML content or use safer alternatives',
        auto_fixable: false
      });
    }
    
    // Unsafe document.write
    if (code.includes('document.write')) {
      threats.push({
        id: 'xss_document_write',
        type: 'xss',
        severity: 'medium',
        description: 'document.write usage can lead to XSS vulnerabilities',
        location: 'document.write call',
        recommendation: 'Use modern DOM manipulation methods instead',
        auto_fixable: true
      });
    }

    return threats;
  }

  private detectInjectionVulnerabilities(code: string): SecurityThreat[] {
    const threats: SecurityThreat[] = [];
    
    // SQL Injection patterns
    const sqlPatterns = [
      /query\s*\+\s*['"]/gi,
      /sql\s*\+\s*['"]/gi,
      /SELECT\s*\*\s*FROM\s*\w+\s*WHERE\s*\w+\s*=\s*['"]/gi
    ];
    
    sqlPatterns.forEach(pattern => {
      if (pattern.test(code)) {
        threats.push({
          id: 'sql_injection',
          type: 'injection',
          severity: 'critical',
          description: 'Potential SQL injection vulnerability detected',
          location: 'SQL query construction',
          recommendation: 'Use parameterized queries or prepared statements',
          auto_fixable: false
        });
      }
    });
    
    // Command injection
    if (code.includes('exec(') || code.includes('system(')) {
      threats.push({
        id: 'command_injection',
        type: 'injection',
        severity: 'critical',
        description: 'Command execution detected - potential command injection',
        location: 'System command execution',
        recommendation: 'Validate and sanitize all user inputs before execution',
        auto_fixable: false
      });
    }

    return threats;
  }

  private detectMaliciousPatterns(code: string): SecurityThreat[] {
    const threats: SecurityThreat[] = [];
    
    // Suspicious patterns
    const maliciousPatterns = [
      { pattern: /eval\s*\(/gi, name: 'eval usage', severity: 'high' as const },
      { pattern: /Function\s*\(/gi, name: 'Function constructor', severity: 'medium' as const },
      { pattern: /setTimeout\s*\(\s*['"]/gi, name: 'setTimeout with string', severity: 'medium' as const },
      { pattern: /setInterval\s*\(\s*['"]/gi, name: 'setInterval with string', severity: 'medium' as const },
      { pattern: /with\s*\(/gi, name: 'with statement', severity: 'medium' as const },
      { pattern: /delete\s+\w+\.\w+/gi, name: 'property deletion', severity: 'low' as const }
    ];
    
    maliciousPatterns.forEach(({ pattern, name, severity }) => {
      if (pattern.test(code)) {
        threats.push({
          id: `malicious_${name.replace(/\s+/g, '_')}`,
          type: 'malicious_code',
          severity,
          description: `Potentially dangerous ${name} detected`,
          location: name,
          recommendation: `Avoid using ${name} or ensure proper validation`,
          auto_fixable: severity === 'low'
        });
      }
    });

    return threats;
  }

  private detectDataLeaks(code: string): SecurityThreat[] {
    const threats: SecurityThreat[] = [];
    
    // Sensitive data patterns
    const sensitivePatterns = [
      { pattern: /password\s*[:=]\s*['"]/gi, name: 'hardcoded password' },
      { pattern: /api[_-]?key\s*[:=]\s*['"]/gi, name: 'hardcoded API key' },
      { pattern: /secret\s*[:=]\s*['"]/gi, name: 'hardcoded secret' },
      { pattern: /token\s*[:=]\s*['"]/gi, name: 'hardcoded token' },
      { pattern: /private[_-]?key\s*[:=]\s*['"]/gi, name: 'hardcoded private key' }
    ];
    
    sensitivePatterns.forEach(({ pattern, name }) => {
      if (pattern.test(code)) {
        threats.push({
          id: `data_leak_${name.replace(/\s+/g, '_')}`,
          type: 'data_leak',
          severity: 'critical',
          description: `Potential ${name} found in code`,
          location: name,
          recommendation: 'Use environment variables or secure configuration',
          auto_fixable: false
        });
      }
    });

    return threats;
  }

  private detectUnsafeEval(code: string): SecurityThreat[] {
    const threats: SecurityThreat[] = [];
    
    if (code.includes('eval(')) {
      threats.push({
        id: 'unsafe_eval',
        type: 'unsafe_eval',
        severity: 'critical',
        description: 'eval() usage detected - major security risk',
        location: 'eval() call',
        recommendation: 'Use JSON.parse() or safer alternatives',
        auto_fixable: false
      });
    }

    return threats;
  }

  private detectPrototypePollution(code: string): SecurityThreat[] {
    const threats: SecurityThreat[] = [];
    
    // Prototype pollution patterns
    if (code.includes('__proto__') || code.includes('constructor.prototype')) {
      threats.push({
        id: 'prototype_pollution',
        type: 'prototype_pollution',
        severity: 'high',
        description: 'Potential prototype pollution vulnerability',
        location: 'Prototype manipulation',
        recommendation: 'Avoid modifying object prototypes',
        auto_fixable: false
      });
    }

    return threats;
  }

  private calculateSecurityScore(threats: SecurityThreat[]): number {
    if (threats.length === 0) return 1.0;
    
    const severityWeights = {
      low: 0.1,
      medium: 0.3,
      high: 0.6,
      critical: 1.0
    };
    
    const totalWeight = threats.reduce((sum, threat) => 
      sum + severityWeights[threat.severity], 0
    );
    
    return Math.max(0, 1 - (totalWeight / 10)); // Normalize to 0-1
  }

  private generateSecurityRecommendations(threats: SecurityThreat[]): string[] {
    const recommendations = new Set<string>();
    
    threats.forEach(threat => {
      recommendations.add(threat.recommendation);
    });
    
    // General security recommendations
    if (threats.length > 0) {
      recommendations.add('Implement input validation for all user data');
      recommendations.add('Use Content Security Policy (CSP) headers');
      recommendations.add('Regular security audits and updates');
    }
    
    return Array.from(recommendations);
  }

  // Auto-fix security issues where possible
  async autoFixSecurityIssues(code: string): Promise<{ fixedCode: string; fixesApplied: string[] }> {
    let fixedCode = code;
    const fixesApplied: string[] = [];
    
    if (this.safetySettings.auto_fix_security_issues) {
      // Fix unsafe innerHTML
      if (fixedCode.includes('innerHTML') && !fixedCode.includes('sanitize')) {
        fixedCode = fixedCode.replace(
          /(\w+)\.innerHTML\s*=\s*([^;]+);?/g,
          '$1.textContent = $2; // Auto-fixed: Changed innerHTML to textContent for security'
        );
        fixesApplied.push('Replaced innerHTML with textContent');
      }
      
      // Fix document.write
      if (fixedCode.includes('document.write')) {
        fixedCode = fixedCode.replace(
          /document\.write\s*\([^)]+\);?/g,
          '// Auto-fixed: Removed unsafe document.write'
        );
        fixesApplied.push('Removed unsafe document.write calls');
      }
      
      // Add input validation template
      if (fixedCode.includes('user') && fixedCode.includes('input')) {
        const validationCode = `
// Auto-added: Input validation for security
function validateInput(input: string): string {
  if (typeof input !== 'string') {
    throw new Error('Invalid input type');
  }
  
  // Sanitize HTML
  const sanitized = input
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
  
  return sanitized;
}
`;
        fixedCode = validationCode + '\n' + fixedCode;
        fixesApplied.push('Added input validation function');
      }
    }
    
    return { fixedCode, fixesApplied };
  }

  // Real-time security monitoring
  startSecurityMonitoring(
    getCode: () => string,
    onThreatDetected: (threat: SecurityThreat) => void
  ): () => void {
    const interval = setInterval(async () => {
      try {
        const code = getCode();
        if (code.trim()) {
          const scan = await this.scanCodeSecurity(code, 'typescript');
          
          scan.threats_found.forEach(threat => {
            if (threat.severity === 'critical' || threat.severity === 'high') {
              onThreatDetected(threat);
            }
          });
        }
      } catch (error) {
        console.warn('Security monitoring error:', error);
      }
    }, 10000); // Scan every 10 seconds

    return () => clearInterval(interval);
  }

  // Privacy protection
  sanitizeUserData(data: any): any {
    if (!this.safetySettings.enable_privacy_protection) return data;
    
    const sensitiveKeys = ['password', 'token', 'key', 'secret', 'private'];
    
    const sanitize = (obj: any): any => {
      if (typeof obj !== 'object' || obj === null) return obj;
      
      if (Array.isArray(obj)) {
        return obj.map(sanitize);
      }
      
      const sanitized: any = {};
      Object.keys(obj).forEach(key => {
        const lowerKey = key.toLowerCase();
        if (sensitiveKeys.some(sensitive => lowerKey.includes(sensitive))) {
          sanitized[key] = '[REDACTED]';
        } else {
          sanitized[key] = sanitize(obj[key]);
        }
      });
      
      return sanitized;
    };
    
    return sanitize(data);
  }

  // Secure code execution environment
  async executeCodeSafely(code: string, language: string): Promise<{
    success: boolean;
    result?: any;
    error?: string;
    securityWarnings: string[];
  }> {
    const securityWarnings: string[] = [];
    
    // Pre-execution security scan
    const scan = await this.scanCodeSecurity(code, language);
    
    if (!scan.safe_to_execute) {
      return {
        success: false,
        error: 'Code execution blocked due to security concerns',
        securityWarnings: scan.threats_found.map(t => t.description)
      };
    }
    
    // Add security warnings for medium threats
    scan.threats_found
      .filter(t => t.severity === 'medium')
      .forEach(threat => {
        securityWarnings.push(threat.description);
      });
    
    try {
      // Execute in sandboxed environment
      const result = await this.sandboxedExecution(code, language);
      
      return {
        success: true,
        result,
        securityWarnings
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Execution failed',
        securityWarnings
      };
    }
  }

  private async sandboxedExecution(code: string, language: string): Promise<any> {
    // Create isolated execution context
    const sandbox = {
      console: {
        log: (...args: any[]) => console.log('[SANDBOX]', ...args),
        error: (...args: any[]) => console.error('[SANDBOX]', ...args),
        warn: (...args: any[]) => console.warn('[SANDBOX]', ...args)
      },
      // Restricted global access
      window: undefined,
      document: undefined,
      eval: undefined,
      Function: undefined
    };
    
    // Execute with timeout and memory limits
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Execution timeout - code took too long to run'));
      }, 5000);
      
      try {
        // Simple execution for demonstration
        // In production, use a proper sandboxing solution
        const result = new Function('sandbox', `
          with (sandbox) {
            ${code}
          }
        `)(sandbox);
        
        clearTimeout(timeout);
        resolve(result);
      } catch (error) {
        clearTimeout(timeout);
        reject(error);
      }
    });
  }

  // User consent management
  async requestUserConsent(operation: string, risks: string[]): Promise<boolean> {
    if (!this.safetySettings.require_confirmation_for_risky_operations) {
      return true;
    }
    
    return new Promise((resolve) => {
      const consent = confirm(
        `Codette wants to ${operation}.\n\n` +
        `Potential risks:\n${risks.map(risk => `• ${risk}`).join('\n')}\n\n` +
        `Do you want to proceed?`
      );
      
      this.logSecurityEvent('user_consent', 'info', {
        operation,
        risks,
        granted: consent
      });
      
      resolve(consent);
    });
  }

  // Secure data storage
  secureStore(key: string, data: any): void {
    try {
      const sanitizedData = this.sanitizeUserData(data);
      const encrypted = this.simpleEncrypt(JSON.stringify(sanitizedData));
      localStorage.setItem(`codette_secure_${key}`, encrypted);
      
      this.logSecurityEvent('secure_storage', 'info', {
        key,
        data_size: JSON.stringify(data).length
      });
    } catch (error) {
      this.logSecurityEvent('storage_error', 'error', {
        key,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  }

  secureRetrieve(key: string): any {
    try {
      const encrypted = localStorage.getItem(`codette_secure_${key}`);
      if (!encrypted) return null;
      
      const decrypted = this.simpleDecrypt(encrypted);
      return JSON.parse(decrypted);
    } catch (error) {
      this.logSecurityEvent('retrieval_error', 'error', {
        key,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      return null;
    }
  }

  private simpleEncrypt(data: string): string {
    // Simple XOR encryption for demo (use proper encryption in production)
    const key = 'codette_security_key_2025';
    let encrypted = '';
    
    for (let i = 0; i < data.length; i++) {
      const charCode = data.charCodeAt(i) ^ key.charCodeAt(i % key.length);
      encrypted += String.fromCharCode(charCode);
    }
    
    return btoa(encrypted);
  }

  private simpleDecrypt(encryptedData: string): string {
    const key = 'codette_security_key_2025';
    const data = atob(encryptedData);
    let decrypted = '';
    
    for (let i = 0; i < data.length; i++) {
      const charCode = data.charCodeAt(i) ^ key.charCodeAt(i % key.length);
      decrypted += String.fromCharCode(charCode);
    }
    
    return decrypted;
  }

  private logSecurityEvent(event: string, severity: string, details: any): void {
    if (!this.safetySettings.log_security_events) return;
    
    const logEntry = {
      timestamp: new Date(),
      event,
      severity,
      details: this.sanitizeUserData(details)
    };
    
    this.securityLog.push(logEntry);
    
    // Keep only last 1000 entries
    if (this.securityLog.length > 1000) {
      this.securityLog = this.securityLog.slice(-500);
    }
    
    // Log to console for debugging
    console.log(`[SECURITY] ${severity.toUpperCase()}: ${event}`, details);
  }

  // Get security settings
  getSecuritySettings(): UserSafetySettings {
    return { ...this.safetySettings };
  }

  // Update security settings
  updateSecuritySettings(settings: Partial<UserSafetySettings>): void {
    this.safetySettings = { ...this.safetySettings, ...settings };
    
    this.logSecurityEvent('settings_updated', 'info', {
      updated_settings: settings
    });
  }

  // Get security log
  getSecurityLog(): typeof this.securityLog {
    return [...this.securityLog];
  }

  // Clear security log
  clearSecurityLog(): void {
    this.securityLog = [];
    this.logSecurityEvent('log_cleared', 'info', {});
  }

  // Emergency security lockdown
  emergencyLockdown(): void {
    this.safetySettings = {
      enable_code_scanning: true,
      block_malicious_patterns: true,
      require_confirmation_for_risky_operations: true,
      enable_privacy_protection: true,
      log_security_events: true,
      auto_fix_security_issues: false // Disable auto-fix in lockdown
    };
    
    this.logSecurityEvent('emergency_lockdown', 'critical', {
      reason: 'Manual security lockdown activated'
    });
    
    alert('Security lockdown activated. All risky operations will require confirmation.');
  }
}

export const securityService = new SecurityService();