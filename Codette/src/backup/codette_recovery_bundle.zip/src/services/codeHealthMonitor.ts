// Code Health Monitor - Comprehensive Health Analysis
export interface CodeHealthMetrics {
  overall_health: number;
  maintainability: number;
  readability: number;
  testability: number;
  security_score: number;
  performance_score: number;
  documentation_score: number;
  code_smells: string[];
  technical_debt: number;
  refactoring_urgency: 'low' | 'medium' | 'high' | 'critical';
}

export interface HealthTrend {
  timestamp: Date;
  health_score: number;
  change_type: 'improvement' | 'degradation' | 'stable';
  contributing_factors: string[];
}

class CodeHealthMonitor {
  private healthHistory: HealthTrend[] = [];
  private isMonitoring = false;
  private monitoringInterval: NodeJS.Timeout | null = null;

  // Comprehensive health analysis
  async analyzeCodeHealth(code: string, language: string): Promise<CodeHealthMetrics> {
    const metrics = {
      overall_health: 0,
      maintainability: this.analyzeMaintainability(code),
      readability: this.analyzeReadability(code),
      testability: this.analyzeTestability(code),
      security_score: this.analyzeSecurityScore(code),
      performance_score: this.analyzePerformanceScore(code),
      documentation_score: this.analyzeDocumentationScore(code),
      code_smells: this.detectCodeSmells(code),
      technical_debt: this.calculateTechnicalDebt(code),
      refactoring_urgency: 'low' as const
    };

    // Calculate overall health
    metrics.overall_health = (
      metrics.maintainability * 0.2 +
      metrics.readability * 0.15 +
      metrics.testability * 0.15 +
      metrics.security_score * 0.2 +
      metrics.performance_score * 0.15 +
      metrics.documentation_score * 0.15
    );

    // Determine refactoring urgency
    metrics.refactoring_urgency = this.determineRefactoringUrgency(metrics);

    return metrics;
  }

  private analyzeMaintainability(code: string): number {
    let score = 0.5;
    
    // Positive indicators
    if (code.includes('interface') || code.includes('type')) score += 0.1;
    if (code.includes('const') && !code.includes('var')) score += 0.1;
    if (code.includes('try') && code.includes('catch')) score += 0.1;
    if (code.includes('export') || code.includes('import')) score += 0.1;
    
    // Negative indicators
    const complexity = this.calculateComplexity(code);
    score -= complexity * 0.3;
    
    if (code.includes('any') && code.includes('typescript')) score -= 0.1;
    if (code.includes('eval') || code.includes('with')) score -= 0.2;
    
    return Math.max(0, Math.min(1, score));
  }

  private analyzeReadability(code: string): number {
    let score = 0.5;
    
    const lines = code.split('\n');
    const avgLineLength = lines.reduce((sum, line) => sum + line.length, 0) / lines.length;
    
    // Good line length (not too long, not too short)
    if (avgLineLength > 20 && avgLineLength < 80) score += 0.2;
    
    // Comments improve readability
    const commentRatio = this.calculateCommentRatio(code);
    score += commentRatio * 0.3;
    
    // Consistent naming
    if (this.hasConsistentNaming(code)) score += 0.2;
    
    // Proper indentation
    if (this.hasProperIndentation(code)) score += 0.1;
    
    return Math.max(0, Math.min(1, score));
  }

  private analyzeTestability(code: string): number {
    let score = 0.3;
    
    // Pure functions are more testable
    if (code.includes('function') && !code.includes('document.') && !code.includes('window.')) {
      score += 0.2;
    }
    
    // Dependency injection improves testability
    if (code.includes('inject') || code.includes('provide')) score += 0.1;
    
    // Small functions are more testable
    const avgFunctionSize = this.calculateAverageFunctionSize(code);
    if (avgFunctionSize < 20) score += 0.2;
    
    // Existing tests
    if (code.includes('test') || code.includes('spec') || code.includes('describe')) {
      score += 0.2;
    }
    
    return Math.max(0, Math.min(1, score));
  }

  private analyzeSecurityScore(code: string): number {
    let score = 0.8; // Start with good security assumption
    
    // Security vulnerabilities
    if (code.includes('eval(')) score -= 0.3;
    if (code.includes('innerHTML') && !code.includes('sanitize')) score -= 0.2;
    if (code.includes('document.write')) score -= 0.2;
    if (code.includes('dangerouslySetInnerHTML')) score -= 0.1;
    
    // Security good practices
    if (code.includes('sanitize') || code.includes('escape')) score += 0.1;
    if (code.includes('validate') || code.includes('check')) score += 0.1;
    if (code.includes('https://') && !code.includes('http://')) score += 0.05;
    
    return Math.max(0, Math.min(1, score));
  }

  private analyzePerformanceScore(code: string): number {
    let score = 0.6;
    
    // Performance anti-patterns
    if (code.includes('for') && code.includes('for')) score -= 0.2; // Nested loops
    if (code.includes('document.getElementById') && code.includes('loop')) score -= 0.1;
    if (code.includes('setTimeout') && code.includes('0')) score -= 0.1;
    
    // Performance good practices
    if (code.includes('useMemo') || code.includes('useCallback')) score += 0.1;
    if (code.includes('React.memo')) score += 0.1;
    if (code.includes('lazy') || code.includes('Suspense')) score += 0.1;
    if (code.includes('debounce') || code.includes('throttle')) score += 0.1;
    
    return Math.max(0, Math.min(1, score));
  }

  private analyzeDocumentationScore(code: string): number {
    const lines = code.split('\n');
    const codeLines = lines.filter(line => line.trim() && !line.trim().startsWith('//')).length;
    const commentLines = lines.filter(line => line.trim().startsWith('//') || line.trim().startsWith('/*')).length;
    
    if (codeLines === 0) return 0;
    
    const commentRatio = commentLines / codeLines;
    let score = Math.min(1, commentRatio * 3); // Good ratio is around 1:3
    
    // JSDoc comments are better
    if (code.includes('/**')) score += 0.2;
    
    // README or documentation files
    if (code.includes('README') || code.includes('documentation')) score += 0.1;
    
    return Math.max(0, Math.min(1, score));
  }

  private detectCodeSmells(code: string): string[] {
    const smells: string[] = [];
    
    // Long functions
    const functions = code.match(/function[^}]*{[^}]*}/g) || [];
    functions.forEach(func => {
      if (func.split('\n').length > 30) {
        smells.push('Long function detected (>30 lines)');
      }
    });
    
    // Magic numbers
    if (code.match(/\b\d{2,}\b/g)) {
      smells.push('Magic numbers detected - consider using named constants');
    }
    
    // Duplicate code
    const lines = code.split('\n');
    const duplicates = this.findDuplicateLines(lines);
    if (duplicates.length > 0) {
      smells.push(`Duplicate code detected (${duplicates.length} instances)`);
    }
    
    // Large classes
    if (code.includes('class') && code.split('class').length > 2) {
      smells.push('Multiple classes in single file');
    }
    
    // TODO/FIXME comments
    if (code.includes('TODO') || code.includes('FIXME')) {
      smells.push('Unfinished code (TODO/FIXME comments)');
    }
    
    return smells;
  }

  private calculateTechnicalDebt(code: string): number {
    let debt = 0;
    
    // Count debt indicators
    const todos = (code.match(/TODO|FIXME/g) || []).length;
    const hacks = (code.match(/hack|workaround|temporary/gi) || []).length;
    const complexity = this.calculateComplexity(code);
    const codeSmells = this.detectCodeSmells(code).length;
    
    debt = (todos * 0.1 + hacks * 0.2 + complexity * 0.4 + codeSmells * 0.05);
    
    return Math.min(1, debt);
  }

  private determineRefactoringUrgency(metrics: CodeHealthMetrics): 'low' | 'medium' | 'high' | 'critical' {
    if (metrics.overall_health < 0.3 || metrics.technical_debt > 0.8) return 'critical';
    if (metrics.overall_health < 0.5 || metrics.technical_debt > 0.6) return 'high';
    if (metrics.overall_health < 0.7 || metrics.technical_debt > 0.4) return 'medium';
    return 'low';
  }

  private calculateComplexity(code: string): number {
    const cyclomaticComplexity = (code.match(/if|else|while|for|switch|case|catch|\?/g) || []).length;
    const nestingDepth = this.calculateNestingDepth(code);
    const linesOfCode = code.split('\n').filter(line => line.trim()).length;
    
    return Math.min(1, (cyclomaticComplexity * 0.4 + nestingDepth * 0.3 + linesOfCode * 0.001));
  }

  private calculateNestingDepth(code: string): number {
    let maxDepth = 0;
    let currentDepth = 0;
    
    for (const char of code) {
      if (char === '{') {
        currentDepth++;
        maxDepth = Math.max(maxDepth, currentDepth);
      } else if (char === '}') {
        currentDepth--;
      }
    }
    
    return maxDepth;
  }

  private calculateCommentRatio(code: string): number {
    const lines = code.split('\n');
    const commentLines = lines.filter(line => 
      line.trim().startsWith('//') || 
      line.trim().startsWith('/*') || 
      line.trim().startsWith('*')
    ).length;
    
    return lines.length > 0 ? commentLines / lines.length : 0;
  }

  private hasConsistentNaming(code: string): boolean {
    const variables = code.match(/(?:let|const|var)\s+(\w+)/g) || [];
    const camelCaseCount = variables.filter(v => /[a-z][A-Z]/.test(v)).length;
    const snake_caseCount = variables.filter(v => /_/.test(v)).length;
    
    // Consistent if one style dominates
    return Math.abs(camelCaseCount - snake_caseCount) > variables.length * 0.7;
  }

  private hasProperIndentation(code: string): boolean {
    const lines = code.split('\n').filter(line => line.trim());
    const indentations = lines.map(line => (line.match(/^\s*/) || [''])[0].length);
    
    // Check for consistent indentation increments
    const increments = new Set();
    for (let i = 1; i < indentations.length; i++) {
      const diff = Math.abs(indentations[i] - indentations[i - 1]);
      if (diff > 0) increments.add(diff);
    }
    
    return increments.size <= 2; // At most 2 different indentation levels
  }

  private calculateAverageFunctionSize(code: string): number {
    const functions = code.match(/function[^}]*{[^}]*}/g) || [];
    if (functions.length === 0) return 0;
    
    const totalLines = functions.reduce((sum, func) => sum + func.split('\n').length, 0);
    return totalLines / functions.length;
  }

  private findDuplicateLines(lines: string[]): string[] {
    const lineMap = new Map<string, number>();
    const duplicates: string[] = [];
    
    lines.forEach(line => {
      const trimmed = line.trim();
      if (trimmed && trimmed.length > 10) { // Only check substantial lines
        const count = lineMap.get(trimmed) || 0;
        lineMap.set(trimmed, count + 1);
        
        if (count === 1) { // Second occurrence
          duplicates.push(trimmed);
        }
      }
    });
    
    return duplicates;
  }

  // Start continuous health monitoring
  startHealthMonitoring(
    getCode: () => string, 
    getLanguage: () => string,
    onHealthUpdate: (metrics: CodeHealthMetrics) => void
  ): void {
    if (this.isMonitoring) return;
    
    this.isMonitoring = true;
    this.monitoringInterval = setInterval(async () => {
      try {
        const code = getCode();
        const language = getLanguage();
        
        if (code.trim()) {
          const metrics = await this.analyzeCodeHealth(code, language);
          onHealthUpdate(metrics);
          
          // Track health trends
          this.trackHealthTrend(metrics);
        }
      } catch (error) {
        console.warn('Health monitoring error:', error);
      }
    }, 10000); // Check every 10 seconds
  }

  stopHealthMonitoring(): void {
    this.isMonitoring = false;
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
  }

  private trackHealthTrend(metrics: CodeHealthMetrics): void {
    const lastHealth = this.healthHistory[this.healthHistory.length - 1];
    let changeType: HealthTrend['change_type'] = 'stable';
    
    if (lastHealth) {
      const diff = metrics.overall_health - lastHealth.health_score;
      if (diff > 0.05) changeType = 'improvement';
      else if (diff < -0.05) changeType = 'degradation';
    }
    
    const trend: HealthTrend = {
      timestamp: new Date(),
      health_score: metrics.overall_health,
      change_type: changeType,
      contributing_factors: this.identifyContributingFactors(metrics)
    };
    
    this.healthHistory.push(trend);
    
    // Keep only last 100 entries
    if (this.healthHistory.length > 100) {
      this.healthHistory = this.healthHistory.slice(-100);
    }
  }

  private identifyContributingFactors(metrics: CodeHealthMetrics): string[] {
    const factors: string[] = [];
    
    if (metrics.maintainability < 0.5) factors.push('Low maintainability');
    if (metrics.security_score < 0.7) factors.push('Security concerns');
    if (metrics.performance_score < 0.6) factors.push('Performance issues');
    if (metrics.documentation_score < 0.4) factors.push('Insufficient documentation');
    if (metrics.code_smells.length > 3) factors.push('Multiple code smells');
    if (metrics.technical_debt > 0.6) factors.push('High technical debt');
    
    return factors;
  }

  // Get health trends
  getHealthTrends(): HealthTrend[] {
    return [...this.healthHistory];
  }

  // Generate health report
  generateHealthReport(metrics: CodeHealthMetrics): string {
    const report = `
# Code Health Report
Generated: ${new Date().toLocaleString()}

## Overall Health: ${(metrics.overall_health * 100).toFixed(0)}%

### Detailed Metrics:
- Maintainability: ${(metrics.maintainability * 100).toFixed(0)}%
- Readability: ${(metrics.readability * 100).toFixed(0)}%
- Testability: ${(metrics.testability * 100).toFixed(0)}%
- Security: ${(metrics.security_score * 100).toFixed(0)}%
- Performance: ${(metrics.performance_score * 100).toFixed(0)}%
- Documentation: ${(metrics.documentation_score * 100).toFixed(0)}%

### Technical Debt: ${(metrics.technical_debt * 100).toFixed(0)}%
### Refactoring Urgency: ${metrics.refactoring_urgency.toUpperCase()}

### Code Smells Detected:
${metrics.code_smells.map(smell => `- ${smell}`).join('\n')}

### Recommendations:
${this.generateRecommendations(metrics).map(rec => `- ${rec}`).join('\n')}
    `;
    
    return report.trim();
  }

  private generateRecommendations(metrics: CodeHealthMetrics): string[] {
    const recommendations: string[] = [];
    
    if (metrics.maintainability < 0.6) {
      recommendations.push('Break down large functions into smaller, focused units');
      recommendations.push('Add type annotations to improve code clarity');
    }
    
    if (metrics.readability < 0.6) {
      recommendations.push('Add more descriptive variable and function names');
      recommendations.push('Include comments explaining complex logic');
    }
    
    if (metrics.testability < 0.6) {
      recommendations.push('Write unit tests for critical functions');
      recommendations.push('Reduce dependencies between components');
    }
    
    if (metrics.security_score < 0.7) {
      recommendations.push('Review and fix security vulnerabilities');
      recommendations.push('Implement input validation and sanitization');
    }
    
    if (metrics.performance_score < 0.6) {
      recommendations.push('Optimize algorithms and data structures');
      recommendations.push('Consider lazy loading and code splitting');
    }
    
    if (metrics.documentation_score < 0.5) {
      recommendations.push('Add comprehensive documentation');
      recommendations.push('Include usage examples and API documentation');
    }
    
    return recommendations;
  }
}

export const codeHealthMonitor = new CodeHealthMonitor();