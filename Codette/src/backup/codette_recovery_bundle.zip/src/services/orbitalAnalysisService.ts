// Orbital Analysis Service - Frontend Integration
export interface AstronomicalClaim {
  text: string;
  source_url?: string;
  verdict: 'approved' | 'likely_hoax' | 'adaptive_intervention' | 'insufficient_evidence';
  hoax_probability: number;
  orbital_facts: any[];
  insights: string[];
  analysis_timestamp: string;
}

export interface AstronomicalObject {
  designation: string;
  fullname: string;
  orbital_data: any;
  close_approaches: any[];
  threat_level: 'none' | 'low' | 'medium' | 'high';
}

class OrbitalAnalysisService {
  private baseUrl = '/api/orbital';

  async analyzeAstronomicalClaim(
    text: string,
    sourceUrl?: string
  ): Promise<AstronomicalClaim> {
    try {
      const response = await fetch(`${this.baseUrl}/analyze`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text,
          source_url: sourceUrl,
          earth_window_start: "2020-01-01",
          earth_window_end: "2030-12-31"
        })
      });

      if (!response.ok) {
        throw new Error(`Analysis failed: ${response.statusText}`);
      }

      const data = await response.json();
      
      return {
        text,
        source_url: sourceUrl,
        verdict: data.verdict,
        hoax_probability: data.hoax_analysis?.hoax_probability || 0,
        orbital_facts: data.live_orbital_facts?.resolved || [],
        insights: data.codette_insights || [],
        analysis_timestamp: data.timestamp
      };
    } catch (error) {
      console.error('Astronomical claim analysis failed:', error);
      throw error;
    }
  }

  async getObjectData(designation: string): Promise<AstronomicalObject> {
    try {
      const response = await fetch(`${this.baseUrl}/object`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ designation })
      });

      if (!response.ok) {
        throw new Error(`Object data retrieval failed: ${response.statusText}`);
      }

      const data = await response.json();
      
      // Assess threat level based on close approaches
      const threatLevel = this.assessThreatLevel(data.close_approaches);
      
      return {
        designation,
        fullname: data.sbdb_data?.object?.fullname || designation,
        orbital_data: data.sbdb_data?.object || {},
        close_approaches: data.close_approaches?.data || [],
        threat_level: threatLevel
      };
    } catch (error) {
      console.error('Object data retrieval failed:', error);
      throw error;
    }
  }

  private assessThreatLevel(closeApproaches: any): AstronomicalObject['threat_level'] {
    if (!closeApproaches?.data || closeApproaches.data.length === 0) {
      return 'none';
    }

    const minDistance = Math.min(...closeApproaches.data.map((approach: any) => parseFloat(approach[4]) || Infinity));
    
    if (minDistance < 0.05) return 'high';      // < 0.05 AU
    if (minDistance < 0.2) return 'medium';     // < 0.2 AU  
    if (minDistance < 1.0) return 'low';        // < 1.0 AU
    return 'none';
  }

  // Extract object designations from text
  extractDesignations(text: string): string[] {
    const patterns = [
      /\b[123]\s*I\s*\/\s*[A-Z][A-Za-z0-9\-']+\b/gi,           // 1I/'Oumuamua, 2I/Borisov, 3I/ATLAS
      /\bC\/\s*\d{4}\s*[A-Z]\d{0,3}(?:\s*\([A-Za-z0-9\- ]+\))?\b/gi, // C/2025 N1 (ATLAS)
      /\b[12]I\s*\([A-Za-z0-9' \-]+\)\b/gi,                    // 1I('Oumuamua) style
      /\b(?:Oumuamua|Borisov|ATLAS)\b/gi                        // Common names
    ];

    const found: string[] = [];
    patterns.forEach(pattern => {
      const matches = text.match(pattern);
      if (matches) {
        found.push(...matches);
      }
    });

    // Deduplicate and normalize
    const normalized = found.map(match => match.trim().replace(/\s+/g, ' '));
    return [...new Set(normalized)];
  }

  private async _apply_codette_analysis(result: any): Promise<any> {
    // Apply Codette's virtue-driven analysis to orbital data
    try {
      const virtue_scores = {
        truth_seeking: result.verdict === 'approved' ? 0.9 : 0.3,
        compassion: 0.85, // Protecting public from misinformation
        wisdom: result.live_orbital_facts?.resolved?.length > 0 ? 0.9 : 0.5,
        integrity: 0.95   // Using authoritative scientific data
      };

      const ethical_assessment = {
        misinformation_risk: result.hoax_analysis?.hoax_probability || 0,
        scientific_accuracy: result.live_orbital_facts?.resolved?.length || 0,
        public_benefit: virtue_scores.compassion * virtue_scores.wisdom
      };

      return {
        virtue_scores,
        ethical_assessment,
        recommendation: this._generate_ai_recommendation(result),
        confidence: this._calculate_confidence(result)
      };
    } catch (error) {
      return { error: `Codette analysis failed: ${error}` };
    }
  }

  private _generate_ai_recommendation(result: any): string {
    const verdict = result.verdict;
    const hoax_prob = result.hoax_analysis?.hoax_probability || 0;
    
    if (verdict === 'likely_hoax') {
      return 'Strong recommendation: Verify with authoritative astronomical sources before sharing';
    } else if (verdict === 'adaptive_intervention') {
      return 'Recommendation: Share scientific facts instead of sensational claims';
    } else if (hoax_prob > 0.5) {
      return 'Caution advised: Cross-reference with NASA/JPL official sources';
    } else {
      return 'Information appears consistent with current astronomical data';
    }
  }

  private _calculate_confidence(result: any): number {
    let confidence = 0.5;
    
    // Higher confidence if we have orbital data
    if (result.live_orbital_facts?.resolved?.length > 0) {
      confidence += 0.3;
    }
    
    // Higher confidence if hoax indicators are clear
    const hoax_prob = result.hoax_analysis?.hoax_probability || 0;
    if (hoax_prob > 0.8 || hoax_prob < 0.2) {
      confidence += 0.2;
    }
    
    return Math.min(1.0, confidence);
  }
}

export const orbitalAnalysisService = new OrbitalAnalysisService();