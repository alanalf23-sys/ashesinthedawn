// OpenAI Service for real AI functionality
interface OpenAIResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

class OpenAIService {
  private apiKey: string;
  private baseUrl = 'https://api.openai.com/v1';

  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    if (!this.apiKey) {
      console.warn('OpenAI API key not found in environment variables');
    }
  }

  async chat(messages: ChatMessage[], model: string = 'gpt-4'): Promise<string> {
    if (!this.apiKey) {
      throw new Error('OpenAI API key not configured');
    }

    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model,
          messages,
          max_tokens: 1000,
          temperature: 0.7
        })
      });

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
      }

      const data: OpenAIResponse = await response.json();
      return data.choices[0]?.message?.content || 'No response generated';
    } catch (error) {
      console.error('OpenAI API call failed:', error);
      throw error;
    }
  }

  async generateCodeCompletion(code: string, language: string): Promise<string> {
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: `You are Codette, an expert AI coding assistant. Provide helpful, accurate code completions and suggestions for ${language} code. Be concise but thorough.`
      },
      {
        role: 'user',
        content: `Complete or improve this ${language} code:\n\n${code}`
      }
    ];

    return await this.chat(messages);
  }

  async explainCode(code: string, language: string): Promise<string> {
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: 'You are Codette, a friendly AI coding mentor. Explain code in a clear, educational way that helps users learn.'
      },
      {
        role: 'user',
        content: `Explain this ${language} code:\n\n${code}`
      }
    ];

    return await this.chat(messages);
  }

  async debugCode(code: string, error: string, language: string): Promise<string> {
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: 'You are Codette, an expert debugging assistant. Help identify and fix code issues with clear explanations.'
      },
      {
        role: 'user',
        content: `Help me debug this ${language} code. Error: ${error}\n\nCode:\n${code}`
      }
    ];

    return await this.chat(messages);
  }

  async optimizeCode(code: string, language: string): Promise<string> {
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: 'You are Codette, a code optimization expert. Suggest improvements for performance, readability, and best practices.'
      },
      {
        role: 'user',
        content: `Optimize this ${language} code:\n\n${code}`
      }
    ];

    return await this.chat(messages);
  }

  async answerQuestion(question: string, context?: string): Promise<string> {
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: 'You are Codette, a helpful AI coding assistant created by Raiff\'s Bits. You are knowledgeable, friendly, and always aim to help developers learn and grow. You have expertise in programming, AI ethics, quantum computing principles, and virtue-driven development.'
      }
    ];

    if (context) {
      messages.push({
        role: 'user',
        content: `Context: ${context}`
      });
    }

    messages.push({
      role: 'user',
      content: question
    });

    return await this.chat(messages);
  }

  isConfigured(): boolean {
    return !!this.apiKey;
  }
}

export const openaiService = new OpenAIService();