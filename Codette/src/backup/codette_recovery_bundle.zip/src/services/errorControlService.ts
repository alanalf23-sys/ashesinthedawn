import { supabase } from './supabase';

export interface ErrorScenario {
  id: string;
  name: string;
  type: 'syntax' | 'runtime' | 'network' | 'security' | 'ai' | 'user';
  severity: 'low' | 'medium' | 'high' | 'critical';
  context: Record<string, any>;
  recovery_strategy: string;
  auto_recoverable: boolean;
  timestamp: Date;
}

export interface ErrorControlConfig {
  enable_auto_recovery: boolean;
  log_all_errors: boolean;
  notify_user_on_critical: boolean;
  max_retry_attempts: number;
  retry_delay_ms: number;
  enable_shadow_monitoring: boolean;
}

class ErrorControlService {
  private errorScenarios: ErrorScenario[] = [];
  private shadowScenarios: ErrorScenario[] = [];
  private config: ErrorControlConfig = {
    enable_auto_recovery: true,
    log_all_errors: true,
    notify_user_on_critical: true,
    max_retry_attempts: 3,
    retry_delay_ms: 1000,
    enable_shadow_monitoring: true
  };
  private errorHistory: Array<{
    error: Error;
    context: any;
    timestamp: Date;
    resolved: boolean;
    recovery_method?: string;
  }> = [];
  private lock = false;

  constructor() {
    this.initializeErrorHandling();
    this.loadErrorScenarios();
  }

  private initializeErrorHandling() {
    // Global error handler
    window.addEventListener('error', (event) => {
      this.handleGlobalError(event.error, {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        type: 'global'
      });
    });

    // Unhandled promise rejection handler
    window.addEventListener('unhandledrejection', (event) => {
      this.handleGlobalError(new Error(event.reason), {
        type: 'unhandled_promise',
        reason: event.reason
      });
    });

    // React error boundary integration
    this.setupReactErrorBoundary();
  }

  private setupReactErrorBoundary() {
    // This would integrate with React error boundaries
    console.log('Error boundary integration ready');
  }

  private async loadErrorScenarios() {
    if (this.lock) return;
    this.lock = true;

    try {
      // Load from database or local storage
      const scenarios = this.generateDefaultScenarios();
      
      // Split into public and shadow scenarios (20% shadow)
      const shuffled = [...scenarios].sort(() => Math.random() - 0.5);
      const splitIndex = Math.floor(scenarios.length * 0.2);
      
      this.shadowScenarios = shuffled.slice(0, splitIndex);
      this.errorScenarios = shuffled.slice(splitIndex);
      
      console.log(`Loaded ${this.errorScenarios.length} error scenarios, ${this.shadowScenarios.length} shadow scenarios`);
    } catch (error) {
      console.warn('Failed to load error scenarios:', error);
    } finally {
      this.lock = false;
    }
  }

  private generateDefaultScenarios(): ErrorScenario[] {
    return [
      {
        id: 'network_timeout',
        name: 'Network Request Timeout',
        type: 'network',
        severity: 'medium',
        context: { timeout_ms: 10000, retry_count: 0 },
        recovery_strategy: 'retry_with_exponential_backoff',
        auto_recoverable: true,
        timestamp: new Date()
      },
      {
        id: 'ai_service_unavailable',
        name: 'AI Service Unavailable',
        type: 'ai',
        severity: 'high',
        context: { service: 'quantum_optimizer', fallback_available: true },
        recovery_strategy: 'use_fallback_service',
        auto_recoverable: true,
        timestamp: new Date()
      },
      {
        id: 'syntax_error_detected',
        name: 'Code Syntax Error',
        type: 'syntax',
        severity: 'medium',
        context: { language: 'typescript', auto_fix_available: true },
        recovery_strategy: 'auto_correct_syntax',
        auto_recoverable: true,
        timestamp: new Date()
      },
      {
        id: 'security_threat_detected',
        name: 'Security Threat in Code',
        type: 'security',
        severity: 'critical',
        context: { threat_type: 'xss', block_execution: true },
        recovery_strategy: 'block_and_sanitize',
        auto_recoverable: false,
        timestamp: new Date()
      },
      {
        id: 'memory_leak_detected',
        name: 'Memory Leak Pattern',
        type: 'runtime',
        severity: 'high',
        context: { memory_usage_mb: 500, threshold_mb: 400 },
        recovery_strategy: 'garbage_collect_and_optimize',
        auto_recoverable: true,
        timestamp: new Date()
      }
    ];
  }

  // Main error handling method with comprehensive recovery
  async handleError(
    error: Error,
    context: any = {},
    options: {
      auto_recover?: boolean;
      notify_user?: boolean;
      log_error?: boolean;
    } = {}
  ): Promise<{
    handled: boolean;
    recovery_applied: boolean;
    user_notification?: string;
    next_action?: string;
  }> {
    const {
      auto_recover = this.config.enable_auto_recovery,
      notify_user = this.config.notify_user_on_critical,
      log_error = this.config.log_all_errors
    } = options;

    try {
      // Find matching error scenario
      const scenario = this.findMatchingScenario(error, context);
      
      // Log error
      if (log_error) {
        await this.logError(error, context, scenario);
      }

      // Add to history
      this.errorHistory.push({
        error,
        context,
        timestamp: new Date(),
        resolved: false
      });

      // Attempt recovery if enabled and scenario supports it
      let recoveryApplied = false;
      if (auto_recover && scenario?.auto_recoverable) {
        recoveryApplied = await this.attemptRecovery(error, scenario, context);
        
        if (recoveryApplied) {
          this.errorHistory[this.errorHistory.length - 1].resolved = true;
          this.errorHistory[this.errorHistory.length - 1].recovery_method = scenario.recovery_strategy;
        }
      }

      // Generate user notification if needed
      let userNotification: string | undefined;
      if (notify_user && scenario?.severity === 'critical') {
        userNotification = this.generateUserNotification(error, scenario, recoveryApplied);
      }

      // Determine next action
      const nextAction = this.determineNextAction(error, scenario, recoveryApplied);

      return {
        handled: true,
        recovery_applied: recoveryApplied,
        user_notification: userNotification,
        next_action: nextAction
      };

    } catch (handlingError) {
      console.error('Error handling failed:', handlingError);
      return {
        handled: false,
        recovery_applied: false,
        user_notification: 'An unexpected error occurred. Please refresh the page.',
        next_action: 'manual_intervention_required'
      };
    }
  }

  private findMatchingScenario(error: Error, context: any): ErrorScenario | null {
    // Check both public and shadow scenarios
    const allScenarios = [...this.errorScenarios];
    if (this.config.enable_shadow_monitoring) {
      allScenarios.push(...this.shadowScenarios);
    }

    // Match by error type and context
    for (const scenario of allScenarios) {
      if (this.matchesScenario(error, context, scenario)) {
        return scenario;
      }
    }

    // Generate adversarial scenario if no match found
    return this.generateAdversarialScenario(error, context);
  }

  private matchesScenario(error: Error, context: any, scenario: ErrorScenario): boolean {
    // Match by error message patterns
    if (error.message.toLowerCase().includes(scenario.name.toLowerCase())) {
      return true;
    }

    // Match by context type
    if (context.type && scenario.type === context.type) {
      return true;
    }

    // Match by severity indicators
    if (error.message.includes('Critical') && scenario.severity === 'critical') {
      return true;
    }

    return false;
  }

  private generateAdversarialScenario(error: Error, context: any): ErrorScenario {
    // Generate new scenario based on error characteristics
    const severity = this.assessErrorSeverity(error, context);
    const type = this.classifyErrorType(error, context);
    
    return {
      id: `generated_${Date.now()}`,
      name: `Generated: ${error.name}`,
      type,
      severity,
      context: { ...context, generated: true },
      recovery_strategy: this.suggestRecoveryStrategy(type, severity),
      auto_recoverable: severity !== 'critical',
      timestamp: new Date()
    };
  }

  private async attemptRecovery(
    error: Error, 
    scenario: ErrorScenario, 
    context: any
  ): Promise<boolean> {
    try {
      switch (scenario.recovery_strategy) {
        case 'retry_with_exponential_backoff':
          return await this.retryWithBackoff(context.operation, context.params);
        
        case 'use_fallback_service':
          return await this.useFallbackService(context.service, context.params);
        
        case 'auto_correct_syntax':
          return await this.autoCorrectSyntax(context.code, context.language);
        
        case 'block_and_sanitize':
          return await this.blockAndSanitize(context.code);
        
        case 'garbage_collect_and_optimize':
          return await this.optimizeMemoryUsage();
        
        default:
          console.warn(`Unknown recovery strategy: ${scenario.recovery_strategy}`);
          return false;
      }
    } catch (recoveryError) {
      console.error('Recovery attempt failed:', recoveryError);
      return false;
    }
  }

  private async retryWithBackoff(operation: Function, params: any): Promise<boolean> {
    for (let attempt = 1; attempt <= this.config.max_retry_attempts; attempt++) {
      try {
        await new Promise(resolve => setTimeout(resolve, this.config.retry_delay_ms * Math.pow(2, attempt - 1)));
        await operation(params);
        return true;
      } catch (error) {
        if (attempt === this.config.max_retry_attempts) {
          return false;
        }
      }
    }
    return false;
  }

  private async useFallbackService(serviceName: string, params: any): Promise<boolean> {
    try {
      // Implement fallback service logic
      console.log(`Using fallback for ${serviceName}`);
      return true;
    } catch (error) {
      return false;
    }
  }

  private async autoCorrectSyntax(code: string, language: string): Promise<boolean> {
    try {
      // Implement syntax auto-correction
      const { aiCodeService } = await import('./aiCodeService');
      const corrections = await aiCodeService.getCodeCorrection(code, language);
      return corrections.length > 0;
    } catch (error) {
      return false;
    }
  }

  private async blockAndSanitize(code: string): Promise<boolean> {
    try {
      // Block execution and sanitize code
      console.warn('Code execution blocked for security reasons');
      return true;
    } catch (error) {
      return false;
    }
  }

  private async optimizeMemoryUsage(): Promise<boolean> {
    try {
      // Force garbage collection if available
      if ('gc' in window && typeof (window as any).gc === 'function') {
        (window as any).gc();
      }
      return true;
    } catch (error) {
      return false;
    }
  }

  private assessErrorSeverity(error: Error, context: any): ErrorScenario['severity'] {
    if (error.message.includes('Critical') || error.message.includes('Security')) {
      return 'critical';
    }
    if (error.message.includes('Network') || error.message.includes('Timeout')) {
      return 'high';
    }
    if (error.message.includes('Warning') || error.message.includes('Deprecated')) {
      return 'medium';
    }
    return 'low';
  }

  private classifyErrorType(error: Error, context: any): ErrorScenario['type'] {
    if (error.message.includes('Syntax') || error.message.includes('Parse')) {
      return 'syntax';
    }
    if (error.message.includes('Network') || error.message.includes('Fetch')) {
      return 'network';
    }
    if (error.message.includes('Security') || error.message.includes('XSS')) {
      return 'security';
    }
    if (context.ai_related || error.message.includes('AI')) {
      return 'ai';
    }
    if (error.message.includes('User') || error.message.includes('Input')) {
      return 'user';
    }
    return 'runtime';
  }

  private suggestRecoveryStrategy(type: ErrorScenario['type'], severity: ErrorScenario['severity']): string {
    if (type === 'network') return 'retry_with_exponential_backoff';
    if (type === 'ai') return 'use_fallback_service';
    if (type === 'syntax') return 'auto_correct_syntax';
    if (type === 'security') return 'block_and_sanitize';
    if (type === 'runtime' && severity === 'high') return 'garbage_collect_and_optimize';
    return 'log_and_continue';
  }

  private generateUserNotification(
    error: Error, 
    scenario: ErrorScenario | null, 
    recoveryApplied: boolean
  ): string {
    if (recoveryApplied) {
      return `Issue resolved automatically: ${scenario?.name || error.message}`;
    }
    
    switch (scenario?.severity) {
      case 'critical':
        return `Critical issue detected: ${error.message}. Please save your work and refresh the page.`;
      case 'high':
        return `Important issue: ${error.message}. Some features may be temporarily unavailable.`;
      case 'medium':
        return `Minor issue: ${error.message}. Functionality may be limited.`;
      default:
        return `Notice: ${error.message}`;
    }
  }

  private determineNextAction(
    error: Error, 
    scenario: ErrorScenario | null, 
    recoveryApplied: boolean
  ): string {
    if (recoveryApplied) return 'continue_normal_operation';
    
    switch (scenario?.severity) {
      case 'critical':
        return 'require_user_intervention';
      case 'high':
        return 'attempt_graceful_degradation';
      case 'medium':
        return 'continue_with_warnings';
      default:
        return 'continue_normal_operation';
    }
  }

  private async logError(error: Error, context: any, scenario: ErrorScenario | null) {
    try {
      const errorLog = {
        error_message: error.message,
        error_stack: error.stack,
        context: JSON.stringify(context),
        scenario_id: scenario?.id,
        severity: scenario?.severity || 'unknown',
        timestamp: new Date().toISOString(),
        user_agent: navigator.userAgent,
        url: window.location.href
      };

      // Log to console instead of Supabase to avoid RLS issues
      console.error('Error logged:', errorLog);

    } catch (loggingError) {
      console.warn('Failed to log error:', loggingError);
    }
  }

  private handleGlobalError(error: Error, context: any) {
    this.handleError(error, { ...context, global: true }, {
      auto_recover: true,
      notify_user: true,
      log_error: true
    });
  }

  // Public methods for components to use
  async safeExecute<T>(
    operation: () => Promise<T>,
    context: any = {},
    fallback?: () => T
  ): Promise<T> {
    try {
      return await operation();
    } catch (error) {
      const result = await this.handleError(error as Error, context);
      
      if (result.recovery_applied) {
        // Try operation again after recovery
        try {
          return await operation();
        } catch (retryError) {
          if (fallback) {
            return fallback();
          }
          throw retryError;
        }
      }
      
      if (fallback) {
        return fallback();
      }
      
      throw error;
    }
  }

  async safeAsyncOperation<T>(
    operation: () => Promise<T>,
    operationName: string,
    fallbackValue?: T
  ): Promise<T> {
    return this.safeExecute(
      operation,
      { operation_name: operationName, ai_related: operationName.includes('ai') },
      fallbackValue ? () => fallbackValue : undefined
    );
  }

  // Get error statistics
  getErrorStatistics(): {
    total_errors: number;
    resolved_errors: number;
    critical_errors: number;
    recovery_rate: number;
    most_common_error_type: string;
  } {
    const totalErrors = this.errorHistory.length;
    const resolvedErrors = this.errorHistory.filter(e => e.resolved).length;
    const criticalErrors = this.errorHistory.filter(e => 
      e.error.message.includes('Critical') || e.error.message.includes('Security')
    ).length;

    const errorTypes = this.errorHistory.reduce((acc, e) => {
      const type = this.classifyErrorType(e.error, e.context);
      acc[type] = (acc[type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const mostCommonType = Object.entries(errorTypes).reduce((a, b) => a[1] > b[1] ? a : b)?.[0] || 'unknown';

    return {
      total_errors: totalErrors,
      resolved_errors: resolvedErrors,
      critical_errors: criticalErrors,
      recovery_rate: totalErrors > 0 ? resolvedErrors / totalErrors : 0,
      most_common_error_type: mostCommonType
    };
  }

  // Update configuration
  updateConfig(newConfig: Partial<ErrorControlConfig>) {
    this.config = { ...this.config, ...newConfig };
  }

  // Get current configuration
  getConfig(): ErrorControlConfig {
    return { ...this.config };
  }

  // Clear error history
  clearErrorHistory() {
    this.errorHistory = [];
  }

  // Get recent errors
  getRecentErrors(limit: number = 10): typeof this.errorHistory {
    return this.errorHistory.slice(-limit);
  }
}

export const errorControlService = new ErrorControlService();