// AI Music Generation Service - Real Music Creation
export interface GeneratedTrack {
  id: string;
  title: string;
  artist: string;
  duration: number;
  audioUrl: string;
  waveform: number[];
  genre: string;
  mood: string;
  tempo: number;
  key: string;
  generatedAt: Date;
  seedPrompt: string;
}

export interface MusicGenerationOptions {
  genre: 'ambient' | 'electronic' | 'classical' | 'jazz' | 'rock' | 'hip-hop' | 'lo-fi' | 'cinematic' | 'mozart' | 'bach' | 'house' | 'dance' | 'techno';
  mood: 'calm' | 'energetic' | 'focused' | 'creative' | 'mysterious' | 'uplifting';
  duration: number; // in seconds
  tempo: number; // BPM
  key?: string;
  instruments?: string[];
  complexity: number; // 0-1 scale
  codingContext?: {
    language: string;
    taskType: 'debugging' | 'coding' | 'designing' | 'learning';
    timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night';
  };
}

class MusicGenerationService {
  private audioContext: AudioContext | null = null;
  private generatedTracks: Map<string, GeneratedTrack> = new Map();
  private isGenerating = false;

  constructor() {
    this.initializeAudioContext();
  }

  private initializeAudioContext() {
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (error) {
      console.warn('Web Audio API not supported:', error);
    }
  }

  // Generate real music using Web Audio API
  async generateMusic(options: MusicGenerationOptions): Promise<GeneratedTrack> {
    if (this.isGenerating) {
      throw new Error('Music generation already in progress');
    }

    this.isGenerating = true;
    
    try {
      const track = await this.createAIMusic(options);
      this.generatedTracks.set(track.id, track);
      return track;
    } finally {
      this.isGenerating = false;
    }
  }

  private async createAIMusic(options: MusicGenerationOptions): Promise<GeneratedTrack> {
    if (!this.audioContext) {
      throw new Error('Audio context not available');
    }

    const { genre, mood, duration, tempo, complexity, codingContext } = options;
    
    // Create audio buffer for the generated track
    const sampleRate = this.audioContext.sampleRate;
    const numSamples = Math.floor(duration * sampleRate);
    const audioBuffer = this.audioContext.createBuffer(2, numSamples, sampleRate);

    // Generate music based on parameters
    const leftChannel = audioBuffer.getChannelData(0);
    const rightChannel = audioBuffer.getChannelData(1);

    // AI-inspired music generation algorithm
    await this.generateMusicData(leftChannel, rightChannel, options, sampleRate);

    // Convert to audio URL
    const audioUrl = await this.bufferToAudioUrl(audioBuffer);

    // Generate waveform for visualization
    const waveform = this.generateWaveform(leftChannel, 200);

    const track: GeneratedTrack = {
      id: `generated-${Date.now()}`,
      title: this.generateTrackTitle(options),
      artist: 'Codette AI Composer',
      duration,
      audioUrl,
      waveform,
      genre,
      mood,
      tempo,
      key: options.key || this.selectOptimalKey(options),
      generatedAt: new Date(),
      seedPrompt: this.createSeedPrompt(options)
    };

    return track;
  }

  private async generateMusicData(
    leftChannel: Float32Array, 
    rightChannel: Float32Array, 
    options: MusicGenerationOptions,
    sampleRate: number
  ): Promise<void> {
    const { genre, mood, tempo, complexity, codingContext } = options;
    
    // Base frequency and harmonic structure
    const baseFreq = this.getBaseFrequency(options.key || 'C');
    const harmonics = this.generateHarmonics(genre, complexity);
    
    // Rhythm patterns based on genre and coding context
    const rhythmPattern = this.generateRhythmPattern(genre, tempo, codingContext);
    
    // Classical composition structure for Mozart/Bach
    const isClassicalMaster = genre === 'mozart' || genre === 'bach';
    const phrases = isClassicalMaster ? this.generateClassicalPhrases(genre, options.duration) : null;
    
    // Electronic elements for dance/house/techno
    const isElectronic = ['house', 'dance', 'techno'].includes(genre);
    const filterEnvelope = isElectronic ? this.generateFilterEnvelope(options.duration, tempo) : null;
    
    // Generate samples
    for (let i = 0; i < leftChannel.length; i++) {
      const time = i / sampleRate;
      const beatTime = (time * tempo) / 60;
      
      let sample = 0;
      
      // Classical phrase structure
      if (isClassicalMaster && phrases) {
        const currentPhrase = this.getCurrentPhrase(time, phrases);
        if (currentPhrase) {
          sample += this.generateClassicalPhrase(time, currentPhrase, baseFreq, harmonics);
        }
      }
      
      // Electronic filter sweeps and effects
      if (isElectronic && filterEnvelope) {
        const filterMod = filterEnvelope[Math.floor((time / options.duration) * filterEnvelope.length)] || 1;
        sample *= filterMod;
      }
      
      // Generate harmonic content
      harmonics.forEach((harmonic, index) => {
        const freq = baseFreq * harmonic.ratio;
        const amplitude = harmonic.amplitude * this.getAmplitudeEnvelope(time, options.duration);
        const phase = harmonic.phase + (time * freq * 2 * Math.PI);
        
        // Apply rhythm modulation
        const rhythmMod = this.getRhythmModulation(beatTime, rhythmPattern);
        
        // Generate waveform based on genre
        const waveform = this.generateWaveform(freq, phase, genre);
        
        // Add genre-specific processing
        let processedWaveform = waveform;
        
        if (genre === 'house' || genre === 'dance') {
          // Add analog-style warmth and saturation
          processedWaveform = Math.tanh(waveform * 1.2) * 0.9;
        } else if (genre === 'techno') {
          // Add industrial distortion
          processedWaveform = Math.tanh(waveform * 1.5) * 0.8;
        } else if (genre === 'mozart' || genre === 'bach') {
          // Pure, clean classical tones
          processedWaveform = waveform * 0.95;
        }
        
        sample += amplitude * processedWaveform * rhythmMod;
      });
      
      // Add genre-specific elements
      if (genre === 'house') {
        // Add house-style bass line
        const bassFreq = baseFreq * 0.5;
        const bassPhase = time * bassFreq * 2 * Math.PI;
        const bassLine = Math.sin(bassPhase) * 0.4 * this.getRhythmModulation(beatTime, [1, 0, 0.5, 0]);
        sample += bassLine;
      }
      
      if (genre === 'dance' || genre === 'techno') {
        // Add electronic percussion elements
        const kickPhase = beatTime * 2 * Math.PI;
        const kick = Math.sin(kickPhase) * Math.exp(-beatTime % 1 * 10) * 0.3;
        sample += kick;
      }
      
      if (genre === 'bach') {
        // Add Bach-style countermelody
        const counterFreq = baseFreq * 1.333; // Perfect fourth
        const counterPhase = time * counterFreq * 2 * Math.PI;
        const counterMelody = Math.sin(counterPhase + Math.PI / 3) * 0.3;
        sample += counterMelody;
      }
      
      // Apply mood-based filtering
      sample = this.applyMoodFilter(sample, mood, time);
      
      // Add ambient textures for coding
      if (codingContext) {
        sample += this.generateAmbientTexture(time, codingContext) * 0.3;
      }
      
      // Stereo processing
      const stereoSpread = this.getStereoSpread(genre);
      leftChannel[i] = sample * (1 - stereoSpread);
      rightChannel[i] = sample * (1 + stereoSpread);
      
      // Apply gentle compression
      leftChannel[i] = this.softCompress(leftChannel[i]);
      rightChannel[i] = this.softCompress(rightChannel[i]);
    }
  }

  // Generate classical phrase structures
  private generateClassicalPhrases(genre: string, duration: number) {
    const phrases = [];
    const phraseLength = genre === 'mozart' ? 8 : 4; // Mozart: longer phrases, Bach: shorter
    const numPhrases = Math.floor(duration / phraseLength);
    
    for (let i = 0; i < numPhrases; i++) {
      phrases.push({
        start: i * phraseLength,
        end: (i + 1) * phraseLength,
        type: genre === 'mozart' ? this.getMozartPhraseType(i) : this.getBachPhraseType(i),
        intensity: 0.5 + Math.sin(i * Math.PI / 4) * 0.3
      });
    }
    
    return phrases;
  }

  private getMozartPhraseType(phraseIndex: number): string {
    const types = ['exposition', 'development', 'recapitulation', 'coda'];
    return types[phraseIndex % types.length];
  }

  private getBachPhraseType(phraseIndex: number): string {
    const types = ['subject', 'answer', 'episode', 'stretto'];
    return types[phraseIndex % types.length];
  }

  private getCurrentPhrase(time: number, phrases: any[]) {
    return phrases.find(phrase => time >= phrase.start && time < phrase.end);
  }

  private generateClassicalPhrase(time: number, phrase: any, baseFreq: number, harmonics: any[]) {
    const phraseTime = time - phrase.start;
    const phraseProgress = phraseTime / (phrase.end - phrase.start);
    
    // Generate melodic line based on phrase type
    let melodicInterval = 1;
    
    if (phrase.type === 'exposition' || phrase.type === 'subject') {
      melodicInterval = 1 + Math.sin(phraseProgress * Math.PI * 2) * 0.2;
    } else if (phrase.type === 'development' || phrase.type === 'episode') {
      melodicInterval = 1 + Math.sin(phraseProgress * Math.PI * 4) * 0.3;
    } else if (phrase.type === 'recapitulation' || phrase.type === 'answer') {
      melodicInterval = 1 + Math.sin(phraseProgress * Math.PI) * 0.15;
    }
    
    const melodicFreq = baseFreq * melodicInterval;
    const melodicPhase = time * melodicFreq * 2 * Math.PI;
    
    return Math.sin(melodicPhase) * phrase.intensity * 0.4;
  }

  // Generate filter envelope for electronic genres
  private generateFilterEnvelope(duration: number, tempo: number): number[] {
    const points = Math.floor(duration * 10); // 10 points per second
    const envelope = [];
    
    for (let i = 0; i < points; i++) {
      const time = i / 10;
      const beatTime = (time * tempo) / 60;
      
      // Create filter sweeps synchronized to the beat
      const filterValue = 0.3 + 0.7 * Math.sin(beatTime * Math.PI / 4);
      envelope.push(filterValue);
    }
    
    return envelope;
  }
  private generateHarmonics(genre: string, complexity: number) {
    switch (genre) {
      case 'mozart':
        // Mozart-inspired harmonics with perfect mathematical ratios
        return [
          { ratio: 1, amplitude: 0.82, phase: 0 },
          { ratio: 1.25, amplitude: 0.65, phase: 0 }, // Major third (5/4)
          { ratio: 1.5, amplitude: 0.58, phase: 0 }, // Perfect fifth (3/2)
          { ratio: 2, amplitude: 0.45, phase: 0 }, // Octave
          { ratio: 2.25, amplitude: 0.35, phase: Math.PI / 4 }, // Major ninth (9/4)
          { ratio: 3, amplitude: 0.25, phase: Math.PI / 2 } // Perfect twelfth
        ];
      
      case 'bach':
        // Bach-inspired counterpoint harmonics
        return [
          { ratio: 1, amplitude: 0.75, phase: 0 },
          { ratio: 1.333, amplitude: 0.68, phase: Math.PI / 6 }, // Perfect fourth (4/3)
          { ratio: 1.5, amplitude: 0.72, phase: Math.PI / 3 }, // Perfect fifth (3/2)
          { ratio: 1.778, amplitude: 0.55, phase: Math.PI / 2 }, // Minor seventh (16/9)
          { ratio: 2, amplitude: 0.63, phase: Math.PI / 4 }, // Octave
          { ratio: 2.667, amplitude: 0.42, phase: Math.PI }, // Compound fifth (8/3)
          { ratio: 3, amplitude: 0.33, phase: Math.PI * 1.5 } // Compound octave
        ];
      
      case 'house':
        // House music harmonics with strong fundamentals
        return [
          { ratio: 1, amplitude: 0.9, phase: 0 },
          { ratio: 2, amplitude: 0.7, phase: 0 },
          { ratio: 4, amplitude: 0.5, phase: Math.PI / 2 },
          { ratio: 8, amplitude: 0.3, phase: Math.PI },
          { ratio: 1.5, amplitude: 0.4, phase: Math.PI / 4 }, // Fifth for warmth
          { ratio: 3, amplitude: 0.2, phase: Math.PI / 3 } // Brightness
        ];
      
      case 'dance':
        // Dance music with punchy harmonics
        return [
          { ratio: 1, amplitude: 0.85, phase: 0 },
          { ratio: 2, amplitude: 0.6, phase: 0 },
          { ratio: 3, amplitude: 0.4, phase: Math.PI / 6 },
          { ratio: 4, amplitude: 0.5, phase: Math.PI / 4 },
          { ratio: 6, amplitude: 0.3, phase: Math.PI / 2 },
          { ratio: 8, amplitude: 0.2, phase: Math.PI }
        ];
      
      case 'techno':
        // Techno with industrial harmonics
        return [
          { ratio: 1, amplitude: 0.8, phase: 0 },
          { ratio: 1.414, amplitude: 0.5, phase: Math.PI / 8 }, // Tritone tension
          { ratio: 2, amplitude: 0.7, phase: 0 },
          { ratio: 2.828, amplitude: 0.4, phase: Math.PI / 4 },
          { ratio: 4, amplitude: 0.6, phase: Math.PI / 2 },
          { ratio: 5.657, amplitude: 0.3, phase: Math.PI }
        ];
      
      case 'ambient':
        return [
          { ratio: 1, amplitude: 0.6, phase: 0 },
          { ratio: 1.5, amplitude: 0.4, phase: Math.PI / 4 },
          { ratio: 2.1, amplitude: 0.3, phase: Math.PI / 2 },
          { ratio: 3.7, amplitude: 0.2, phase: Math.PI },
          { ratio: 5.2, amplitude: 0.1, phase: Math.PI * 1.5 }
        ];
      
      case 'electronic':
        return [
          { ratio: 1, amplitude: 0.7, phase: 0 },
          { ratio: 2, amplitude: 0.5, phase: 0 },
          { ratio: 4, amplitude: 0.3, phase: Math.PI / 2 },
          { ratio: 8, amplitude: 0.2, phase: Math.PI }
        ];
      
      case 'classical':
        return [
          { ratio: 1, amplitude: 0.8, phase: 0 },
          { ratio: 2, amplitude: 0.6, phase: 0 },
          { ratio: 3, amplitude: 0.4, phase: 0 },
          { ratio: 4, amplitude: 0.3, phase: 0 },
          { ratio: 5, amplitude: 0.2, phase: 0 }
        ];
      
      case 'lo-fi':
        return [
          { ratio: 1, amplitude: 0.7, phase: 0 },
          { ratio: 1.2, amplitude: 0.4, phase: Math.PI / 6 },
          { ratio: 2.1, amplitude: 0.3, phase: Math.PI / 3 },
          { ratio: 3.3, amplitude: 0.2, phase: Math.PI / 2 }
        ];
      
      default:
        return [
          { ratio: 1, amplitude: 0.8, phase: 0 },
          { ratio: 2, amplitude: 0.4, phase: 0 },
          { ratio: 3, amplitude: 0.2, phase: 0 },
          { ratio: 4, amplitude: 0.1, phase: 0 }
        ].map(h => ({
          ...h,
          amplitude: h.amplitude * (0.5 + complexity * 0.5)
        }));
    }
  }

  private generateRhythmPattern(genre: string, tempo: number, codingContext?: any) {
    const beatsPerMeasure = 4;
    const pattern = new Array(beatsPerMeasure).fill(0);

    switch (genre) {
      case 'mozart':
        // Mozart's elegant, balanced rhythms
        return pattern.map((_, i) => {
          const elegantPattern = [0.8, 0.4, 0.6, 0.3];
          return elegantPattern[i] + Math.sin(i * Math.PI / 3) * 0.1;
        });
      
      case 'bach':
        // Bach's complex counterpoint rhythms
        return pattern.map((_, i) => {
          const contrapuntal = [0.7, 0.5, 0.8, 0.4];
          const polyrhythm = Math.sin(i * Math.PI / 2) * 0.2;
          return contrapuntal[i] + polyrhythm;
        });
      
      case 'house':
        // Classic house 4/4 kick pattern
        return pattern.map((_, i) => {
          const housePattern = [1.0, 0.3, 0.6, 0.3]; // Strong kick on 1 and 3
          const hiHat = i % 2 === 1 ? 0.4 : 0; // Hi-hat on off-beats
          return housePattern[i] + hiHat;
        });
      
      case 'dance':
        // Energetic dance rhythm
        return pattern.map((_, i) => {
          const dancePattern = [0.9, 0.4, 0.8, 0.5];
          const syncopation = Math.sin(i * Math.PI / 1.5) * 0.2;
          return dancePattern[i] + syncopation;
        });
      
      case 'techno':
        // Driving techno beat
        return pattern.map((_, i) => {
          const technoPattern = [1.0, 0.2, 0.7, 0.2]; // Strong kick, subtle snare
          const industrialNoise = (Math.random() - 0.5) * 0.1;
          return technoPattern[i] + industrialNoise;
        });
      
      case 'ambient':
        // Gentle, flowing rhythm
        return pattern.map((_, i) => 0.3 + Math.sin(i * Math.PI / 2) * 0.2);
      
      case 'electronic':
        // Strong 4/4 beat
        return pattern.map((_, i) => i % 2 === 0 ? 0.8 : 0.4);
      
      case 'lo-fi':
        // Relaxed, slightly off-beat
        return pattern.map((_, i) => 0.5 + Math.sin(i * Math.PI / 3) * 0.3);
      
      case 'classical':
        // Complex, varied rhythm
        return pattern.map((_, i) => 0.4 + Math.sin(i * Math.PI / 1.5) * 0.4);
      
      default:
        return pattern.map(() => 0.5);
    }
  }

  private getBaseFrequency(key: string): number {
    const frequencies: Record<string, number> = {
      'C': 261.63,
      'C#': 277.18,
      'D': 293.66,
      'D#': 311.13,
      'E': 329.63,
      'F': 349.23,
      'F#': 369.99,
      'G': 392.00,
      'G#': 415.30,
      'A': 440.00,
      'A#': 466.16,
      'B': 493.88
    };
    return frequencies[key] || frequencies['C'];
  }

  private generateWaveform(freq: number, phase: number, genre: string): number {
    switch (genre) {
      case 'mozart':
        // Mozart's pure, crystalline tones with subtle ornamentation
        const mozartBase = Math.sin(phase) * 0.8;
        const ornamentation = Math.sin(phase * 4) * 0.1 * Math.sin(phase * 0.25);
        const elegance = Math.sin(phase * 1.5) * 0.15;
        return mozartBase + ornamentation + elegance;
      
      case 'bach':
        // Bach's complex polyphonic textures
        const bachVoice1 = Math.sin(phase) * 0.6;
        const bachVoice2 = Math.sin(phase * 1.333) * 0.5; // Perfect fourth
        const bachVoice3 = Math.sin(phase * 1.5) * 0.4; // Perfect fifth
        const bachVoice4 = Math.sin(phase * 2) * 0.3; // Octave
        return bachVoice1 + bachVoice2 + bachVoice3 + bachVoice4;
      
      case 'house':
        // House music with warm analog-style synthesis
        const houseSaw = this.generateSawtooth(phase) * 0.7;
        const houseFilter = Math.sin(phase * 0.1) * 0.3 + 0.7; // Slow filter sweep
        const houseBass = Math.sin(phase * 0.5) * 0.4; // Sub bass
        return (houseSaw * houseFilter + houseBass) * 0.8;
      
      case 'dance':
        // Energetic dance synthesis
        const danceSquare = Math.sign(Math.sin(phase)) * 0.6;
        const danceSaw = this.generateSawtooth(phase) * 0.5;
        const danceArp = Math.sin(phase * 8) * 0.3 * Math.sin(phase * 0.125); // Arpeggios
        return danceSquare + danceSaw + danceArp;
      
      case 'techno':
        // Industrial techno synthesis
        const technoSaw = this.generateSawtooth(phase) * 0.8;
        const technoNoise = (Math.random() - 0.5) * 0.2;
        const technoFilter = Math.sin(phase * 0.05) * 0.4 + 0.6; // Resonant filter
        const technoBass = Math.sin(phase * 0.25) * 0.6; // Deep bass
        return (technoSaw + technoNoise) * technoFilter + technoBass;
      
      case 'ambient':
        // Soft sine waves with subtle harmonics
        return Math.sin(phase) * 0.7 + Math.sin(phase * 1.5) * 0.2 + Math.sin(phase * 2.1) * 0.1;
      
      case 'electronic':
        // Square waves with filtering
        const square = Math.sign(Math.sin(phase));
        return square * 0.6 + Math.sin(phase) * 0.4;
      
      case 'classical':
        // Rich harmonic content
        return Math.sin(phase) * 0.6 + 
               Math.sin(phase * 2) * 0.3 + 
               Math.sin(phase * 3) * 0.1;
      
      case 'lo-fi':
        // Warm, slightly distorted sine
        const base = Math.sin(phase);
        return base + Math.sin(phase * 3) * 0.1 + (Math.random() - 0.5) * 0.05;
      
      default:
        return Math.sin(phase);
    }
  }

  // Generate sawtooth wave for electronic genres
  private generateSawtooth(phase: number): number {
    return 2 * ((phase / (2 * Math.PI)) % 1) - 1;
  }

  // Generate square wave
  private generateSquare(phase: number): number {
    return Math.sign(Math.sin(phase));
  }

  // Generate triangle wave
  private generateTriangle(phase: number): number {
    const normalized = (phase / (2 * Math.PI)) % 1;
    return normalized < 0.5 ? 4 * normalized - 1 : 3 - 4 * normalized;
  }
  private getAmplitudeEnvelope(time: number, duration: number): number {
    const attackTime = 0.1;
    const releaseTime = 2.0;
    
    if (time < attackTime) {
      return time / attackTime;
    } else if (time > duration - releaseTime) {
      return (duration - time) / releaseTime;
    }
    return 1.0;
  }

  private getRhythmModulation(beatTime: number, pattern: number[]): number {
    const beatIndex = Math.floor(beatTime) % pattern.length;
    const beatFraction = beatTime - Math.floor(beatTime);
    
    const currentBeat = pattern[beatIndex];
    const nextBeat = pattern[(beatIndex + 1) % pattern.length];
    
    // Smooth interpolation between beats
    return currentBeat + (nextBeat - currentBeat) * beatFraction;
  }

  private applyMoodFilter(sample: number, mood: string, time: number): number {
    switch (mood) {
      case 'calm':
        // Low-pass filtering effect
        return sample * (0.7 + 0.3 * Math.sin(time * 0.5));
      
      case 'energetic':
        // Slight distortion and brightness
        return Math.tanh(sample * 1.2) * 0.9;
      
      case 'focused':
        // Clean, precise sound
        return sample * 0.8;
      
      case 'creative':
        // Add subtle modulation
        return sample * (0.9 + 0.1 * Math.sin(time * 2));
      
      case 'mysterious':
        // Dark, atmospheric processing
        return sample * (0.6 + 0.4 * Math.sin(time * 0.3));
      
      default:
        return sample;
    }
  }

  private generateAmbientTexture(time: number, codingContext: any): number {
    const { language, taskType } = codingContext;
    
    // Generate coding-specific ambient sounds
    let texture = 0;
    
    // Keyboard typing simulation
    if (Math.random() < 0.01) {
      texture += (Math.random() - 0.5) * 0.1;
    }
    
    // Language-specific textures
    switch (language) {
      case 'javascript':
        texture += Math.sin(time * 0.7) * 0.05;
        break;
      case 'python':
        texture += Math.sin(time * 0.5) * 0.03;
        break;
      case 'rust':
        texture += Math.sin(time * 1.2) * 0.04;
        break;
    }
    
    return texture;
  }

  private getStereoSpread(genre: string): number {
    switch (genre) {
      case 'mozart': return 0.2; // Balanced classical stereo
      case 'bach': return 0.3; // Wide polyphonic spread
      case 'house': return 0.4; // Wide house stereo
      case 'dance': return 0.5; // Maximum dance energy
      case 'techno': return 0.3; // Industrial spread
      case 'ambient': return 0.3;
      case 'electronic': return 0.2;
      case 'classical': return 0.4;
      case 'lo-fi': return 0.1;
      default: return 0.2;
    }
  }

  private softCompress(sample: number): number {
    const threshold = 0.7;
    const ratio = 3;
    
    if (Math.abs(sample) > threshold) {
      const excess = Math.abs(sample) - threshold;
      const compressed = threshold + excess / ratio;
      return Math.sign(sample) * compressed;
    }
    
    return sample;
  }

  private async bufferToAudioUrl(audioBuffer: AudioBuffer): Promise<string> {
    // Convert AudioBuffer to WAV format
    const wav = this.audioBufferToWav(audioBuffer);
    const blob = new Blob([wav], { type: 'audio/wav' });
    return URL.createObjectURL(blob);
  }

  private audioBufferToWav(buffer: AudioBuffer): ArrayBuffer {
    const length = buffer.length;
    const numberOfChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const arrayBuffer = new ArrayBuffer(44 + length * numberOfChannels * 2);
    const view = new DataView(arrayBuffer);

    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length * numberOfChannels * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, numberOfChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * numberOfChannels * 2, true);
    view.setUint16(32, numberOfChannels * 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length * numberOfChannels * 2, true);

    // Convert float samples to 16-bit PCM
    let offset = 44;
    for (let i = 0; i < length; i++) {
      for (let channel = 0; channel < numberOfChannels; channel++) {
        const sample = Math.max(-1, Math.min(1, buffer.getChannelData(channel)[i]));
        view.setInt16(offset, sample * 0x7FFF, true);
        offset += 2;
      }
    }

    return arrayBuffer;
  }

  private generateWaveform(audioData: Float32Array, points: number): number[] {
    const waveform: number[] = [];
    const samplesPerPoint = Math.floor(audioData.length / points);
    
    for (let i = 0; i < points; i++) {
      let sum = 0;
      const start = i * samplesPerPoint;
      const end = Math.min(start + samplesPerPoint, audioData.length);
      
      for (let j = start; j < end; j++) {
        sum += Math.abs(audioData[j]);
      }
      
      waveform.push(sum / (end - start));
    }
    
    return waveform;
  }

  private generateTrackTitle(options: MusicGenerationOptions): string {
    const { genre, mood, codingContext } = options;
    
    const titleTemplates = {
      mozart: [
        'Sonata for Algorithms',
        'Eine Kleine Code Music',
        'Piano Concerto in C++',
        'Symphony of Functions',
        'Elegant Code Variations',
        'Minuet in Binary',
        'Rondo for Recursion'
      ],
      bach: [
        'Fugue in Code Major',
        'Well-Tempered Algorithms',
        'Brandenburg Concerto No. Debug',
        'Art of the Function',
        'Goldberg Variables',
        'Invention in Two Parts',
        'Prelude and Fugue in Git'
      ],
      house: [
        'Deep House Coding',
        'Progressive Development',
        'Soulful Algorithms',
        'Vocal Code House',
        'Underground Programming',
        'Chicago Code Style',
        'Acid House Debugging'
      ],
      dance: [
        'Euphoric Code Rush',
        'Trance Programming',
        'Uplifting Development',
        'Hands Up for Clean Code',
        'Festival of Functions',
        'EDM Algorithm Drop',
        'Rave Code Energy'
      ],
      techno: [
        'Detroit Code Machine',
        'Industrial Programming',
        'Minimal Techno Logic',
        'Berlin Code Underground',
        'Acid Techno Debugging',
        'Warehouse Code Sessions',
        'Driving Bass Algorithms'
      ],
      ambient: [
        'Floating Through Code',
        'Digital Meditation',
        'Algorithmic Dreams',
        'Peaceful Debugging',
        'Zen Programming'
      ],
      electronic: [
        'Compile Time Energy',
        'Runtime Pulse',
        'Binary Beats',
        'Syntax Surge',
        'Code Acceleration'
      ],
      'lo-fi': [
        'Late Night Coding',
        'Coffee and Commits',
        'Debugging Vibes',
        'Chill Development',
        'Relaxed Refactoring'
      ],
      classical: [
        'Symphony of Algorithms',
        'Concerto for Code',
        'Elegant Solutions',
        'Harmonic Functions',
        'Classical Computing'
      ]
    };

    const templates = titleTemplates[genre as keyof typeof titleTemplates] || titleTemplates.ambient;
    const baseTitle = templates[Math.floor(Math.random() * templates.length)];
    
    if (codingContext?.language) {
      return `${baseTitle} (${codingContext.language})`;
    }
    
    return baseTitle;
  }

  private createSeedPrompt(options: MusicGenerationOptions): string {
    const { genre, mood, tempo, codingContext } = options;
    
    let prompt = `Generate ${genre} music with ${mood} mood at ${tempo} BPM`;
    
    if (codingContext) {
      prompt += ` for ${codingContext.language} ${codingContext.taskType} during ${codingContext.timeOfDay}`;
    }
    
    return prompt;
  }

  private selectOptimalKey(options: MusicGenerationOptions): string {
    const { mood, genre, codingContext } = options;
    
    // AI-selected keys based on mood and context
    const keyMappings = {
      calm: ['C', 'F', 'G', 'Am', 'Dm'],
      energetic: ['D', 'A', 'E', 'Bm', 'F#m'],
      focused: ['C', 'G', 'Am', 'Em'],
      creative: ['F', 'Bb', 'Dm', 'Gm'],
      mysterious: ['Am', 'Em', 'Bm', 'F#m', 'C#m']
    };
    
    const keys = keyMappings[mood as keyof typeof keyMappings] || keyMappings.focused;
    return keys[Math.floor(Math.random() * keys.length)];
  }

  // Preset generation for common coding scenarios
  async generateCodingPlaylist(scenario: 'deep-focus' | 'debugging' | 'creative' | 'learning'): Promise<GeneratedTrack[]> {
    const tracks: GeneratedTrack[] = [];
    
    const scenarios = {
      'deep-focus': [
        { genre: 'ambient' as const, mood: 'focused' as const, duration: 300, tempo: 60 },
        { genre: 'classical' as const, mood: 'calm' as const, duration: 240, tempo: 70 },
        { genre: 'ambient' as const, mood: 'mysterious' as const, duration: 360, tempo: 55 }
      ],
      'debugging': [
        { genre: 'lo-fi' as const, mood: 'calm' as const, duration: 180, tempo: 80 },
        { genre: 'ambient' as const, mood: 'focused' as const, duration: 200, tempo: 65 },
        { genre: 'classical' as const, mood: 'calm' as const, duration: 220, tempo: 75 }
      ],
      'creative': [
        { genre: 'electronic' as const, mood: 'creative' as const, duration: 200, tempo: 120 },
        { genre: 'jazz' as const, mood: 'creative' as const, duration: 180, tempo: 110 },
        { genre: 'ambient' as const, mood: 'uplifting' as const, duration: 240, tempo: 90 }
      ],
      'learning': [
        { genre: 'classical' as const, mood: 'focused' as const, duration: 300, tempo: 80 },
        { genre: 'ambient' as const, mood: 'calm' as const, duration: 250, tempo: 70 },
        { genre: 'lo-fi' as const, mood: 'focused' as const, duration: 200, tempo: 85 }
      ]
    };

    const trackConfigs = scenarios[scenario];
    
    for (const config of trackConfigs) {
      try {
        const track = await this.generateMusic({
          ...config,
          complexity: 0.6,
          codingContext: {
            language: 'typescript',
            taskType: scenario === 'debugging' ? 'debugging' : 'coding',
            timeOfDay: 'afternoon'
          }
        });
        tracks.push(track);
      } catch (error) {
        console.warn('Failed to generate track:', error);
      }
    }
    
    return tracks;
  }

  // Real-time adaptive music generation
  async generateAdaptiveTrack(
    currentCode: string, 
    language: string, 
    complexity: number
  ): Promise<GeneratedTrack> {
    // Analyze code to determine optimal music parameters
    const codeAnalysis = this.analyzeCodeForMusic(currentCode, language, complexity);
    
    const options: MusicGenerationOptions = {
      genre: codeAnalysis.recommendedGenre,
      mood: codeAnalysis.recommendedMood,
      duration: 300, // 5 minutes
      tempo: codeAnalysis.optimalTempo,
      complexity: complexity,
      codingContext: {
        language,
        taskType: codeAnalysis.taskType,
        timeOfDay: this.getCurrentTimeOfDay()
      }
    };

    return await this.generateMusic(options);
  }

  private analyzeCodeForMusic(code: string, language: string, complexity: number) {
    let recommendedGenre: MusicGenerationOptions['genre'] = 'mozart';
    let recommendedMood: MusicGenerationOptions['mood'] = 'focused';
    let optimalTempo = 70;
    let taskType: 'debugging' | 'coding' | 'designing' | 'learning' = 'coding';

    // Analyze code patterns
    if (code.includes('debug') || code.includes('console.log') || code.includes('try') || code.includes('catch')) {
      taskType = 'debugging';
      recommendedGenre = 'bach'; // Bach for complex problem solving
      recommendedMood = 'calm';
      optimalTempo = 80;
    } else if (code.includes('class') || code.includes('interface') || code.includes('type')) {
      taskType = 'designing';
      recommendedGenre = 'mozart'; // Mozart for elegant design
      recommendedMood = 'creative';
      optimalTempo = 90;
    } else if (complexity > 0.7) {
      recommendedGenre = 'bach'; // Bach for complex algorithms
      recommendedMood = 'focused';
      optimalTempo = 60;
    } else if (complexity < 0.3) {
      taskType = 'learning';
      recommendedGenre = 'house'; // House for energetic learning
      recommendedMood = 'energetic';
      optimalTempo = 100;
    } else if (code.includes('react') || code.includes('component')) {
      recommendedGenre = 'dance'; // Dance for UI development
      recommendedMood = 'creative';
      optimalTempo = 128;
    } else if (code.includes('api') || code.includes('fetch')) {
      recommendedGenre = 'techno'; // Techno for backend work
      recommendedMood = 'energetic';
      optimalTempo = 135;
    }

    return {
      recommendedGenre,
      recommendedMood,
      optimalTempo,
      taskType
    };
  }

  private getCurrentTimeOfDay(): 'morning' | 'afternoon' | 'evening' | 'night' {
    const hour = new Date().getHours();
    if (hour < 6) return 'night';
    if (hour < 12) return 'morning';
    if (hour < 18) return 'afternoon';
    if (hour < 22) return 'evening';
    return 'night';
  }

  // Get generated tracks
  getGeneratedTracks(): GeneratedTrack[] {
    return Array.from(this.generatedTracks.values());
  }

  // Clear generated tracks to free memory
  clearGeneratedTracks(): void {
    this.generatedTracks.forEach(track => {
      if (track.audioUrl.startsWith('blob:')) {
        URL.revokeObjectURL(track.audioUrl);
      }
    });
    this.generatedTracks.clear();
  }

  // Check if generation is in progress
  isGeneratingMusic(): boolean {
    return this.isGenerating;
  }
}

export const musicGenerationService = new MusicGenerationService();