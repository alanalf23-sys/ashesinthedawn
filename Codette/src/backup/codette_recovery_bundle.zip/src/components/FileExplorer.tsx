import React, { useState, useEffect } from 'react';
import { useAutoScroll } from '../hooks/useAutoScroll';
import { 
  Folder, 
  FolderOpen, 
  File, 
  Plus, 
  MoreHorizontal,
  FileText,
  Code,
  Image,
  Settings,
  X,
  Trash2,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { FileType } from '../types/file';

interface FileExplorerProps {
  files: FileType[];
  activeFile: FileType | null;
  onFileSelect: (file: FileType) => void;
  onFileCreate: (name: string, type: 'file' | 'folder') => void;
  onFileDelete: (id: string) => void;
}

export function FileExplorer({ 
  files, 
  activeFile, 
  onFileSelect, 
  onFileCreate, 
  onFileDelete 
}: FileExplorerProps) {
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const fileListScroll = useAutoScroll({
    speed: 20, 
    pauseOnHover: true,
    resetOnInteraction: true,
    enabled: files.length > 10 // Only enable if many files
  });

  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set());
  const [showCreateMenu, setShowCreateMenu] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    try {
      const checkMobile = () => {
        try {
          setIsMobile(window.innerWidth < 768);
        } catch (err) {
          console.error('Error checking mobile state:', err);
          setError('Failed to detect device type');
        }
      };
      
      checkMobile();
      window.addEventListener('resize', checkMobile);
      
      return () => {
        try {
          window.removeEventListener('resize', checkMobile);
        } catch (err) {
          console.error('Error removing resize listener:', err);
        }
      };
    } catch (err) {
      console.error('Error setting up mobile detection:', err);
      setError('Failed to initialize mobile detection');
    }
  }, []);

  const toggleFolder = (folderId: string) => {
    try {
      const newExpanded = new Set(expandedFolders);
      if (newExpanded.has(folderId)) {
        newExpanded.delete(folderId);
      } else {
        newExpanded.add(folderId);
      }
      setExpandedFolders(newExpanded);
    } catch (err) {
      console.error('Error toggling folder:', err);
      setError('Failed to toggle folder');
    }
  };

  const handleFileSelect = (file: FileType) => {
    try {
      setError(null);
      onFileSelect(file);
    } catch (err) {
      console.error('Error selecting file:', err);
      setError(`Failed to open file: ${file.name}`);
    }
  };

  const handleFileDelete = (id: string) => {
    try {
      setError(null);
      onFileDelete(id);
    } catch (err) {
      console.error('Error deleting file:', err);
      setError('Failed to delete file');
    }
  };

  const getFileIcon = (file: FileType) => {
    try {
      if (file.type === 'folder') {
        return expandedFolders.has(file.id) ? (
          <FolderOpen className="w-4 h-4 text-blue-500" />
        ) : (
          <Folder className="w-4 h-4 text-blue-500" />
        );
      }

      const extension = file.name.split('.').pop()?.toLowerCase();
      switch (extension) {
      case 'js':
      case 'mjs':
      case 'ts':
      case 'jsx':
      case 'tsx':
        return <Code className="w-4 h-4 text-yellow-500" />;
      case 'css':
      case 'scss':
      case 'less':
        return <Code className="w-4 h-4 text-blue-500" />;
      case 'jsx':
        return <Code className="w-4 h-4 text-cyan-500" />;
      case 'tsx':
        return <Code className="w-4 h-4 text-blue-600" />;
      case 'py':
      case 'pyw':
        return <Code className="w-4 h-4 text-green-500" />;
      case 'java':
        return <Code className="w-4 h-4 text-red-500" />;
      case 'cpp':
      case 'cc':
      case 'cxx':
      case 'c':
      case 'h':
        return <Code className="w-4 h-4 text-blue-700" />;
      case 'rs':
        return <Code className="w-4 h-4 text-orange-600" />;
      case 'go':
        return <Code className="w-4 h-4 text-cyan-600" />;
      case 'php':
        return <Code className="w-4 h-4 text-purple-600" />;
      case 'rb':
        return <Code className="w-4 h-4 text-red-600" />;
      case 'swift':
        return <Code className="w-4 h-4 text-orange-500" />;
      case 'kt':
      case 'kts':
        return <Code className="w-4 h-4 text-purple-500" />;
      case 'scala':
      case 'scss':
      case 'sass':
      case 'less':
        return <Code className="w-4 h-4 text-red-700" />;
      case 'html':
      case 'htm':
        return <Code className="w-4 h-4 text-orange-500" />;
      case 'json':
        return <Settings className="w-4 h-4 text-green-500" />;
      case 'xml':
        return <Code className="w-4 h-4 text-orange-400" />;
      case 'yml':
      case 'yaml':
        return <Settings className="w-4 h-4 text-blue-400" />;
      case 'toml':
        return <Settings className="w-4 h-4 text-gray-600" />;
      case 'md':
      case 'markdown':
        return <FileText className="w-4 h-4 text-blue-600" />;
      case 'sql':
        return <Code className="w-4 h-4 text-blue-800" />;
      case 'sh':
      case 'bash':
      case 'zsh':
        return <Code className="w-4 h-4 text-green-600" />;
      case 'ps1':
        return <Code className="w-4 h-4 text-blue-700" />;
      case 'dockerfile':
        return <Code className="w-4 h-4 text-blue-500" />;
      case 'vue':
        return <Code className="w-4 h-4 text-green-600" />;
      case 'svelte':
        return <Code className="w-4 h-4 text-orange-600" />;
      case 'r':
        return <Code className="w-4 h-4 text-blue-600" />;
      case 'lua':
        return <Code className="w-4 h-4 text-blue-500" />;
      case 'pl':
      case 'pm':
        return <Code className="w-4 h-4 text-blue-700" />;
      case 'hs':
        return <Code className="w-4 h-4 text-purple-700" />;
      case 'clj':
      case 'cljs':
        return <Code className="w-4 h-4 text-green-700" />;
      case 'erl':
        return <Code className="w-4 h-4 text-red-500" />;
      case 'ex':
      case 'exs':
        return <Code className="w-4 h-4 text-purple-600" />;
      case 'dart':
        return <Code className="w-4 h-4 text-blue-500" />;
      case 'fs':
      case 'fsx':
        return <Code className="w-4 h-4 text-blue-600" />;
      case 'ml':
      case 'mli':
        return <Code className="w-4 h-4 text-orange-700" />;
      case 'asm':
      case 's':
        return <Code className="w-4 h-4 text-gray-600" />;
      case 'vhd':
      case 'vhdl':
        return <Code className="w-4 h-4 text-purple-500" />;
      case 'v':
      case 'vh':
        return <Code className="w-4 h-4 text-green-500" />;
      case 'm':
        return <Code className="w-4 h-4 text-orange-500" />;
      case 'tex':
        return <FileText className="w-4 h-4 text-green-600" />;
      case 'png':
      case 'jpg':
      case 'jpeg':
      case 'gif':
      case 'svg':
      case 'webp':
      case 'ico':
        return <Image className="w-4 h-4 text-purple-500" />;
      case 'pdf':
        return <FileText className="w-4 h-4 text-red-500" />;
      case 'zip':
      case 'tar':
      case 'gz':
      case 'rar':
        return <Settings className="w-4 h-4 text-gray-600" />;
      default:
        return <FileText className="w-4 h-4 text-gray-500" />;
      }
    } catch (err) {
      console.error('Error getting file icon:', err);
      return <FileText className="w-4 h-4 text-gray-500" />;
    }
  };

  const handleCreateFile = () => {
    try {
      setError(null);
      const name = prompt('Enter file name:');
      if (name && name.trim()) {
        onFileCreate(name.trim(), 'file');
      }
    } catch (err) {
      console.error('Error creating file:', err);
      setError('Failed to create file');
    }
    setShowCreateMenu(false);
  };

  const handleCreateFolder = () => {
    try {
      setError(null);
      const name = prompt('Enter folder name:');
      if (name && name.trim()) {
        onFileCreate(name.trim(), 'folder');
      }
    } catch (err) {
      console.error('Error creating folder:', err);
      setError('Failed to create folder');
    }
    setShowCreateMenu(false);
  };

  const clearError = () => {
    setError(null);
  };

  const renderFile = (file: FileType, depth = 0) => {
    try {
    const isActive = activeFile?.id === file.id;
    const isExpanded = expandedFolders.has(file.id);

    return (
      <div key={file.id}>
        <div
          className={`
            flex items-center px-3 py-2 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 
            transition-colors group touch-target
            ${isActive ? 'bg-blue-50 dark:bg-blue-900/30 border-r-2 border-blue-500' : ''}
          `}
          style={{ paddingLeft: `${isMobile ? 8 + depth * 12 : 12 + depth * 20}px` }}
          onClick={() => {
            if (file.type === 'folder') {
              toggleFolder(file.id);
            } else {
              onFileSelect(file);
            }
          }}
        >
          {getFileIcon(file)}
          <span className={`
            ${isMobile ? 'ml-2' : 'ml-3'} ${isMobile ? 'text-xs' : 'text-sm'} truncate flex-1 font-medium
            ${isActive 
              ? 'text-blue-700 dark:text-blue-300 font-medium' 
              : 'text-gray-700 dark:text-gray-300'
            }
          `}>
            {file.name}
          </span>
          
          {file.modified && (
            <div className={`w-2 h-2 bg-orange-500 rounded-full ${isMobile ? 'ml-2' : 'ml-3'} animate-pulse`} />
          )}
          
          <button
            className={`${isMobile ? 'p-2' : 'p-1'} opacity-0 group-hover:opacity-100 hover:bg-red-100 dark:hover:bg-red-900 rounded transition-all touch-target`}
            onClick={(e) => {
              try {
                e.stopPropagation();
                if (window.confirm(`Are you sure you want to delete "${file.name}"?`)) {
                  handleFileDelete(file.id);
                }
              } catch (err) {
                console.error('Error deleting file:', err);
                setError(`Failed to delete ${file.name}`);
              }
            }}
            title="Delete file"
          >
            <Trash2 className="w-3 h-3 text-red-500 hover:text-red-600" />
          </button>
        </div>
        
        {file.type === 'folder' && isExpanded && file.children && (
          <div className={`border-l border-gray-200 dark:border-gray-600 ${isMobile ? 'ml-2' : 'ml-4'}`}>
              {file.children.map(child => {
                try {
                  return renderFile(child, depth + 1);
                } catch (err) {
                  console.error('Error rendering child file:', err);
                  return (
                    <div key={child.id} className="p-2 text-red-500 text-xs">
                      Error loading {child.name}
                    </div>
                  );
                }
              })}
          </div>
        )}
      </div>
    );
    } catch (err) {
      console.error('Error rendering file:', err);
      return (
        <div key={file.id} className="p-2 text-red-500 text-xs flex items-center space-x-2">
          <AlertTriangle className="w-3 h-3" />
          <span>Error loading {file.name}</span>
        </div>
      );
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Error Display */}
      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 border-b border-red-200/50 dark:border-red-700/50 p-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <span className="text-sm text-red-800 dark:text-red-200 font-medium">{error}</span>
            </div>
            <button
              onClick={clearError}
              className="p-1 hover:bg-red-100 dark:hover:bg-red-800 rounded-lg transition-colors"
            >
              <X className="w-3 h-3 text-red-600" />
            </button>
          </div>
        </div>
      )}

      <div className={`flex items-center justify-between ${isMobile ? 'p-3' : 'p-4'} border-b border-gray-200/50 dark:border-gray-700/50`}>
        <h2 className={`${isMobile ? 'text-sm' : 'text-sm'} font-semibold text-gray-900 dark:text-gray-100 tracking-wide`}>
          Explorer
        </h2>
        
        <div className="relative">
          <button
            onClick={() => setShowCreateMenu(!showCreateMenu)}
            className={`${isMobile ? 'p-2' : 'p-2'} hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-all duration-200 hover:scale-105 touch-target`}
            title="New File/Folder"
            disabled={isLoading}
          >
            {isLoading ? (
              <RefreshCw className="w-4 h-4 text-gray-600 dark:text-gray-300 animate-spin" />
            ) : (
              <Plus className="w-4 h-4 text-gray-600 dark:text-gray-300" />
            )}
          </button>
          
          {showCreateMenu && (
            <div className={`absolute right-0 ${isMobile ? 'top-10' : 'top-10'} bg-white dark:bg-gray-800 border border-gray-200/50 dark:border-gray-700/50 rounded-xl shadow-xl py-2 z-10 ${isMobile ? 'min-w-36' : ''} animate-scale-in`}>
              <button
                onClick={handleCreateFile}
                className={`w-full ${isMobile ? 'px-3 py-2' : 'px-4 py-2'} text-left ${isMobile ? 'text-sm' : 'text-sm'} hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors touch-target font-medium`}
              >
                New File
              </button>
              <button
                onClick={handleCreateFolder}
                className={`w-full ${isMobile ? 'px-3 py-2' : 'px-4 py-2'} text-left ${isMobile ? 'text-sm' : 'text-sm'} hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors touch-target font-medium`}
              >
                New Folder
              </button>
            </div>
          )}
        </div>
      </div>
      
      <div 
        ref={fileListScroll.elementRef}
        className="flex-1 overflow-y-auto relative"
      >
        {files.length > 0 ? (
          files.map(file => {
            try {
              return renderFile(file);
            } catch (err) {
              console.error('Error rendering file in list:', err);
              return (
                <div key={file.id} className="p-3 text-red-500 text-sm flex items-center space-x-2">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Error loading {file.name}</span>
                </div>
              );
            }
          })
        ) : (
          <div className="p-6 text-center text-gray-500 dark:text-gray-400">
            <FileText className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p className="text-sm font-medium">No files yet</p>
            <p className="text-xs font-medium">Click + to create your first file</p>
          </div>
        )}
        
        {/* Auto-scroll indicator - only show if many files */}
        {files.length > 10 && (
          <div className="absolute top-2 right-2 flex items-center space-x-2 glass rounded-full px-3 py-1.5">
            <div className={`w-2 h-2 rounded-full ${fileListScroll.isPaused ? 'bg-yellow-500' : 'bg-green-500 animate-pulse'}`} />
            <span className="text-xs text-gray-600 dark:text-gray-400 font-medium">
              {fileListScroll.isPaused ? 'Paused' : 'Auto'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}