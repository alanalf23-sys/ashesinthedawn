import React, { useState, useEffect } from 'react';
import { useAutoScroll } from '../hooks/useAutoScroll';
import { 
  Brain, 
  Zap, 
  Activity, 
  Shield, 
  Network,
  ChevronDown,
  ChevronRight,
  Play,
  Pause,
  RotateCcw,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users,
  Sparkles,
  Eye
} from 'lucide-react';
import { AIAnticipationPanel } from './AIAnticipationPanel';
import { CreativeCodeGenerator } from './CreativeCodeGenerator';
import { OrbitalAnalysisPanel } from './OrbitalAnalysisPanel';

interface AIAnalysis {
  id: string;
  timestamp: string;
  mode: string;
  input_signal: string;
  filtered_signal: string;
  anchors?: any;
  dynamics_result?: any;
  council_decision?: any;
}

interface MemoryEntry {
  id: string;
  timestamp: string;
  emotion_tag: string;
  content: string;
  action: string;
}

interface BenchmarkResult {
  id: string;
  test_type: string;
  query: string;
  codette_score: number;
  competitor_scores: any;
  improvement: number;
  processing_time: number;
}

interface AIPanelProps {
  currentCode?: string;
  language?: string;
  onCodeGenerated?: (code: string, title?: string) => void;
}

export function AIPanel({ currentCode = '', language = 'typescript', onCodeGenerated }: AIPanelProps) {
  const [backendConnected, setBackendConnected] = useState(false);

  useEffect(() => {
    // Check backend connection
    fetch('/api/health')
      .then(response => response.ok ? setBackendConnected(true) : setBackendConnected(false))
      .catch(() => setBackendConnected(false));
  }, []);

  const analysisScroll = useAutoScroll({ 
    speed: 40, 
    pauseOnHover: true,
    resetOnInteraction: true 
  });
  
  const memoryScroll = useAutoScroll({ 
    speed: 35, 
    pauseOnHover: true,
    resetOnInteraction: true 
  });
  
  const benchmarkScroll = useAutoScroll({ 
    speed: 30, 
    pauseOnHover: true,
    resetOnInteraction: true 
  });

  const [activeTab, setActiveTab] = useState<'analysis' | 'memory' | 'benchmarks' | 'council' | 'anticipation' | 'creative'>('analysis');
  const [isProcessing, setIsProcessing] = useState(false);
  const [analyses, setAnalyses] = useState<AIAnalysis[]>([]);
  const [memories, setMemories] = useState<MemoryEntry[]>([]);
  const [benchmarks, setBenchmarks] = useState<BenchmarkResult[]>([]);
  const [councilStatus, setCouncilStatus] = useState<'idle' | 'active' | 'consensus'>('idle');
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['overview']));

  const toggleSection = (section: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(section)) {
      newExpanded.delete(section);
    } else {
      newExpanded.add(section);
    }
    setExpandedSections(newExpanded);
  };

  const runQuantumAnalysis = async () => {
    setIsProcessing(true);
    try {
      if (!backendConnected) {
        alert('🔬 Quantum Analysis requires Python backend connection.\n\nThis is a frontend demo. The real quantum optimization algorithms are implemented in Python and documented in research papers.\n\nCheck the GitHub repository for backend setup instructions.');
        return;
      }
      // Real quantum analysis would happen here
    } catch (error) {
      console.error('Quantum analysis not available:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const runCouncilAnalysis = async () => {
    setCouncilStatus('active');
    try {
      if (!backendConnected) {
        alert('🏛️ Aegis Council requires Python backend connection.\n\nThe multi-agent AI system with virtue-based reasoning is implemented in Python. This frontend shows the interface design.\n\nSee GitHub for the full implementation.');
        return;
      }
      // Real council analysis would happen here
    } catch (error) {
      console.error('Council analysis not available:', error);
    } finally {
      setCouncilStatus('idle');
    }
  };

  const runBenchmark = async () => {
    setIsProcessing(true);
    try {
      if (!backendConnected) {
        alert('📊 Performance Benchmarking requires backend connection.\n\nReal statistical analysis and competitor comparisons are implemented in the Python backend.\n\nThis demo shows the interface and data visualization.');
        return;
      }
      // Real benchmarking would happen here
    } catch (error) {
      console.error('Benchmark not available:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-white dark:bg-gray-900">
      {/* AI Panel Header */}
      <div className="p-6 border-b border-gray-200/50 dark:border-gray-700/50 bg-gradient-to-r from-slate-50 to-gray-50 dark:from-gray-800 dark:to-gray-900">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">
                Codette AI Core
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">
                Advanced AI Analysis & Optimization by Raiff's Bits
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${
              councilStatus === 'active' ? 'bg-yellow-500 animate-pulse' :
              councilStatus === 'consensus' ? 'bg-green-500' : 'bg-gray-400'
            }`} />
            <span className="text-sm text-gray-600 dark:text-gray-400 capitalize font-medium">
              {councilStatus}
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 bg-gray-100 dark:bg-gray-800 rounded-xl p-1.5">
          {[
            { id: 'analysis', label: 'Quantum Analysis', icon: Zap },
            { id: 'memory', label: 'Memory Core', icon: Activity },
            { id: 'benchmarks', label: 'Benchmarks', icon: Shield },
            { id: 'council', label: 'Aegis Council', icon: Users },
            { id: 'anticipation', label: 'Anticipate', icon: Eye },
            { id: 'creative', label: 'Create', icon: Sparkles },
            { id: 'orbital', label: 'Orbital', icon: Satellite }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-white dark:bg-gray-700 text-blue-600 dark:text-blue-400 shadow-md'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {activeTab === 'analysis' && (
          <div className="space-y-6">
            {/* Quantum Analysis Controls */}
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-200/50 dark:border-gray-700/50 hover:shadow-md transition-shadow duration-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white tracking-tight">
                  Quantum Multi-Objective Optimizer
                  {!backendConnected && (
                    <span className="ml-2 px-2 py-1 bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-300 text-xs rounded-full font-medium">
                      Demo Mode
                    </span>
                  )}
                </h3>
                <button
                  onClick={runQuantumAnalysis}
                  disabled={isProcessing || !backendConnected}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-200 ${
                    backendConnected 
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700 shadow-md hover:shadow-lg'
                      : 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                  } disabled:opacity-50`}
                >
                  {isProcessing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span className="font-medium">{isProcessing ? 'Processing...' : backendConnected ? 'Run Analysis' : 'Backend Required'}</span>
                </button>
              </div>
              
              {!backendConnected && (
                <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200/50 dark:border-amber-700/50 rounded-xl p-4 mb-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span className="font-medium text-amber-800 dark:text-amber-200">Frontend Demo Mode</span>
                  </div>
                  <p className="text-sm text-amber-700 dark:text-amber-300 font-medium">
                    The quantum optimization algorithms are implemented in Python and require backend connection. 
                    This interface shows how the real system would work. Check the GitHub repository for setup instructions.
                  </p>
                </div>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-purple-50 dark:bg-purple-900/20 rounded-xl p-4 border border-purple-200/50 dark:border-purple-800/50">
                  <div className="flex items-center space-x-2 mb-2">
                    <Zap className="w-5 h-5 text-purple-600" />
                    <span className="font-medium text-gray-900 dark:text-white">Optimization</span>
                  </div>
                  <p className="text-2xl font-bold text-purple-600">87%</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">Efficiency Score</p>
                </div>
                
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4 border border-blue-200/50 dark:border-blue-800/50">
                  <div className="flex items-center space-x-2 mb-2">
                    <Network className="w-5 h-5 text-blue-600" />
                    <span className="font-medium text-gray-900 dark:text-white">Pareto Front</span>
                  </div>
                  <p className="text-2xl font-bold text-blue-600">15</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">Solutions Found</p>
                </div>
                
                <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-xl p-4 border border-emerald-200/50 dark:border-emerald-800/50">
                  <div className="flex items-center space-x-2 mb-2">
                    <Clock className="w-5 h-5 text-emerald-600" />
                    <span className="font-medium text-gray-900 dark:text-white">Processing</span>
                  </div>
                  <p className="text-2xl font-bold text-emerald-600">2.3s</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">Convergence Time</p>
                </div>
              </div>

              {/* Recent Analyses */}
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-3 tracking-tight">Recent Analyses</h4>
                <div 
                  ref={analysisScroll.elementRef}
                  className="space-y-2 max-h-64 overflow-y-auto relative"
                >
                  {analyses.map(analysis => (
                    <div key={analysis.id} className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4 border border-gray-200/50 dark:border-gray-700/50 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-gray-900 dark:text-white">{analysis.mode}</span>
                        <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                          {new Date(analysis.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mb-1 font-medium">{analysis.input_signal}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">{analysis.filtered_signal}</p>
                    </div>
                  ))}
                  
                  {/* Auto-scroll indicator */}
                  <div className="absolute top-2 right-2 flex items-center space-x-2 glass rounded-full px-3 py-1.5">
                    <div className={`w-2 h-2 rounded-full ${analysisScroll.isPaused ? 'bg-yellow-500' : 'bg-green-500 animate-pulse'}`} />
                    <span className="text-xs text-gray-600 dark:text-gray-400 font-medium">
                      {analysisScroll.isPaused ? 'Paused' : 'Auto'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'memory' && (
          <div className="space-y-6">
            {/* Memory Core */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-blue-100 dark:border-gray-700">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
                  Nexus Memory System
                </h3>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">Active</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Activity className="w-5 h-5 text-blue-600" />
                    <span className="font-medium text-gray-800 dark:text-white">Memory Entries</span>
                  </div>
                  <p className="text-2xl font-bold text-blue-600">{memories.length}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Active Memories</p>
                </div>
                
                <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Shield className="w-5 h-5 text-purple-600" />
                    <span className="font-medium text-gray-800 dark:text-white">Emotional Weight</span>
                  </div>
                  <p className="text-2xl font-bold text-purple-600">0.73</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Average Intensity</p>
                </div>
              </div>

              {/* Memory Entries */}
              <div>
                <h4 className="font-medium text-gray-800 dark:text-white mb-3">Recent Memories</h4>
                <div 
                  ref={memoryScroll.elementRef}
                  className="space-y-2 max-h-64 overflow-y-auto relative"
                >
                  {memories.map(memory => (
                    <div key={memory.id} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          memory.emotion_tag === 'wisdom' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200' :
                          memory.emotion_tag === 'compassion' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                          memory.emotion_tag === 'curiosity' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' :
                          'bg-gray-100 text-gray-800 dark:bg-gray-600 dark:text-gray-200'
                        }`}>
                          {memory.emotion_tag}
                        </span>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {new Date(memory.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-300">{memory.content}</p>
                    </div>
                  ))}
                  
                  {/* Auto-scroll indicator */}
                  <div className="absolute top-2 right-2 flex items-center space-x-2 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-lg px-2 py-1">
                    <div className={`w-2 h-2 rounded-full ${memoryScroll.isPaused ? 'bg-yellow-500' : 'bg-green-500 animate-pulse'}`} />
                    <span className="text-xs text-gray-600 dark:text-gray-400">
                      {memoryScroll.isPaused ? 'Paused' : 'Auto'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'benchmarks' && (
          <div className="space-y-6">
            {/* Benchmark Results */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-green-100 dark:border-gray-700">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
                  Performance Benchmarks
                </h3>
                <button
                  onClick={runBenchmark}
                  disabled={isProcessing}
                  className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-lg hover:from-green-600 hover:to-emerald-700 disabled:opacity-50 transition-all"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Run Benchmark</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="font-medium text-gray-800 dark:text-white">Codette Score</span>
                  </div>
                  <p className="text-2xl font-bold text-green-600">92%</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Performance Rating</p>
                </div>
                
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Activity className="w-5 h-5 text-blue-600" />
                    <span className="font-medium text-gray-800 dark:text-white">Improvement</span>
                  </div>
                  <p className="text-2xl font-bold text-blue-600">+17%</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">vs Competitors</p>
                </div>
                
                <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Clock className="w-5 h-5 text-purple-600" />
                    <span className="font-medium text-gray-800 dark:text-white">Processing</span>
                  </div>
                  <p className="text-2xl font-bold text-purple-600">1.2s</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Average Time</p>
                </div>
              </div>

              {/* Benchmark History */}
              <div>
                <h4 className="font-medium text-gray-800 dark:text-white mb-3">Benchmark History</h4>
                <div 
                  ref={benchmarkScroll.elementRef}
                  className="space-y-2 max-h-64 overflow-y-auto relative"
                >
                  {benchmarks.map(benchmark => (
                    <div key={benchmark.id} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-gray-800 dark:text-white">{benchmark.test_type}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-green-600">
                            +{(benchmark.improvement * 100).toFixed(0)}%
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {benchmark.processing_time}s
                          </span>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-300">{benchmark.query}</p>
                    </div>
                  ))}
                  
                  {/* Auto-scroll indicator */}
                  <div className="absolute top-2 right-2 flex items-center space-x-2 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-lg px-2 py-1">
                    <div className={`w-2 h-2 rounded-full ${benchmarkScroll.isPaused ? 'bg-yellow-500' : 'bg-green-500 animate-pulse'}`} />
                    <span className="text-xs text-gray-600 dark:text-gray-400">
                      {benchmarkScroll.isPaused ? 'Paused' : 'Auto'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'council' && (
          <div className="space-y-6">
            {/* Aegis Council */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-orange-100 dark:border-gray-700">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
                  Aegis Council
                </h3>
                <button
                  onClick={runCouncilAnalysis}
                  disabled={councilStatus !== 'idle'}
                  className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-lg hover:from-orange-600 hover:to-red-700 disabled:opacity-50 transition-all"
                >
                  <Users className="w-4 h-4" />
                  <span>Convene Council</span>
                </button>
              </div>

              {/* Council Agents */}
              <div className="space-y-4">
                {[
                  { name: 'MetaJudgeAgent', status: 'active', virtue: 'wisdom', score: 0.87 },
                  { name: 'TemporalAgent', status: 'active', virtue: 'foresight', score: 0.92 },
                  { name: 'VirtueAgent', status: 'active', virtue: 'ethics', score: 0.89 },
                  { name: 'EthicalFilter', status: 'monitoring', virtue: 'integrity', score: 0.95 }
                ].map(agent => (
                  <div key={agent.name} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${
                        agent.status === 'active' ? 'bg-green-500' : 'bg-yellow-500'
                      }`} />
                      <div>
                        <p className="font-medium text-gray-800 dark:text-white">{agent.name}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{agent.virtue}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-800 dark:text-white">
                        {(agent.score * 100).toFixed(0)}%
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Reliability</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Virtue Profile */}
              <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-lg">
                <h4 className="font-medium text-gray-800 dark:text-white mb-3">Current Virtue Profile</h4>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { virtue: 'Compassion', score: 0.85, color: 'text-green-600' },
                    { virtue: 'Integrity', score: 0.92, color: 'text-blue-600' },
                    { virtue: 'Courage', score: 0.78, color: 'text-orange-600' },
                    { virtue: 'Wisdom', score: 0.89, color: 'text-purple-600' }
                  ].map(item => (
                    <div key={item.virtue} className="flex items-center justify-between">
                      <span className="text-sm text-gray-700 dark:text-gray-300">{item.virtue}</span>
                      <span className={`font-medium ${item.color}`}>
                        {(item.score * 100).toFixed(0)}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'anticipation' && (
          <AIAnticipationPanel
            currentCode={currentCode}
            language={language}
            onCodeGenerated={(code) => onCodeGenerated?.(code)}
          />
        )}

        {activeTab === 'creative' && (
          <CreativeCodeGenerator
            onCodeGenerated={(code, title) => onCodeGenerated?.(code, title)}
          />
        )}

        {activeTab === 'orbital' && (
          <OrbitalAnalysisPanel />
        )}
      </div>

      {/* Processing Indicator */}
      {isProcessing && (
        <div className="absolute inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-xl">
            <div className="flex items-center space-x-3">
              <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
              <span className="text-gray-800 dark:text-white font-medium">
                AI Analysis in Progress...
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}