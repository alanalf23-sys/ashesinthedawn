import React, { useState } from 'react';
import { 
  Globe, 
  Satellite, 
  AlertTriangle, 
  CheckCircle, 
  Eye, 
  Shield,
  Brain,
  Zap,
  Target,
  Clock,
  TrendingUp,
  ExternalLink
} from 'lucide-react';
import { orbitalAnalysisService, AstronomicalClaim, AstronomicalObject } from '../services/orbitalAnalysisService';

export function OrbitalAnalysisPanel() {
  const [analysisText, setAnalysisText] = useState('');
  const [sourceUrl, setSourceUrl] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AstronomicalClaim | null>(null);
  const [objectData, setObjectData] = useState<AstronomicalObject | null>(null);

  const analyzeAstronomicalClaim = async () => {
    if (!analysisText.trim()) return;
    
    setIsAnalyzing(true);
    try {
      const result = await orbitalAnalysisService.analyzeAstronomicalClaim(
        analysisText,
        sourceUrl || undefined
      );
      setAnalysisResult(result);
      
      // If objects were found, get detailed data for the first one
      if (result.orbital_facts.length > 0) {
        const firstObject = result.orbital_facts[0];
        if (firstObject.resolved_fullname) {
          const objData = await orbitalAnalysisService.getObjectData(firstObject.resolved_fullname);
          setObjectData(objData);
        }
      }
    } catch (error) {
      console.error('Analysis failed:', error);
      alert('Analysis failed. Please check your input and try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getVerdictColor = (verdict: string) => {
    switch (verdict) {
      case 'approved': return 'text-green-600 bg-green-100 dark:bg-green-900/20';
      case 'likely_hoax': return 'text-red-600 bg-red-100 dark:bg-red-900/20';
      case 'adaptive_intervention': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20';
      case 'insufficient_evidence': return 'text-orange-600 bg-orange-100 dark:bg-orange-900/20';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20';
    }
  };

  const getThreatLevelColor = (level: string) => {
    switch (level) {
      case 'none': return 'text-green-600';
      case 'low': return 'text-yellow-600';
      case 'medium': return 'text-orange-600';
      case 'high': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-blue-100 dark:border-gray-700">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
          <Satellite className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
            Orbital Analysis System
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Live JPL/NASA data integration with AI analysis
          </p>
        </div>
      </div>

      {/* Input Section */}
      <div className="space-y-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Astronomical Claim or Text to Analyze:
          </label>
          <textarea
            value={analysisText}
            onChange={(e) => setAnalysisText(e.target.value)}
            placeholder="Enter text mentioning astronomical objects (e.g., '3I/ATLAS is heading toward Earth' or 'C/2025 N1 will impact our planet')..."
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-800 dark:text-white bg-white dark:bg-gray-700 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows={4}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Source URL (optional):
          </label>
          <input
            type="url"
            value={sourceUrl}
            onChange={(e) => setSourceUrl(e.target.value)}
            placeholder="https://example.com/article"
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-800 dark:text-white bg-white dark:bg-gray-700 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        
        <button
          onClick={analyzeAstronomicalClaim}
          disabled={!analysisText.trim() || isAnalyzing}
          className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 transition-all"
        >
          {isAnalyzing ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              <span>Analyzing with JPL/NASA data...</span>
            </>
          ) : (
            <>
              <Globe className="w-5 h-5" />
              <span>Analyze with Live Orbital Data</span>
            </>
          )}
        </button>
      </div>

      {/* Analysis Results */}
      {analysisResult && (
        <div className="space-y-6">
          {/* Verdict */}
          <div className={`p-4 rounded-lg ${getVerdictColor(analysisResult.verdict)}`}>
            <div className="flex items-center space-x-2 mb-2">
              {analysisResult.verdict === 'approved' ? (
                <CheckCircle className="w-5 h-5" />
              ) : (
                <AlertTriangle className="w-5 h-5" />
              )}
              <h4 className="font-semibold capitalize">
                {analysisResult.verdict.replace('_', ' ')}
              </h4>
            </div>
            <p className="text-sm">
              Hoax Probability: {(analysisResult.hoax_probability * 100).toFixed(0)}%
            </p>
          </div>

          {/* AI Insights */}
          {analysisResult.insights.length > 0 && (
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-3">
                <Brain className="w-5 h-5 text-blue-600" />
                <h4 className="font-medium text-gray-800 dark:text-white">AI Analysis Insights</h4>
              </div>
              <ul className="space-y-2">
                {analysisResult.insights.map((insight, index) => (
                  <li key={index} className="flex items-start space-x-2 text-sm text-gray-700 dark:text-gray-300">
                    <Zap className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                    <span>{insight}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Orbital Facts */}
          {analysisResult.orbital_facts.length > 0 && (
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-3">
                <Satellite className="w-5 h-5 text-green-600" />
                <h4 className="font-medium text-gray-800 dark:text-white">Live Orbital Data</h4>
              </div>
              <div className="space-y-3">
                {analysisResult.orbital_facts.map((fact, index) => (
                  <div key={index} className="border border-green-200 dark:border-green-700 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <h5 className="font-medium text-gray-800 dark:text-white">
                        {fact.resolved_fullname || fact.query}
                      </h5>
                      {fact.closest_approach && (
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          Min Distance: {fact.closest_approach.dist_au?.toFixed(3)} AU
                        </span>
                      )}
                    </div>
                    
                    {fact.closest_approach && (
                      <div className="text-sm text-gray-600 dark:text-gray-300">
                        <p>Closest Approach: {fact.closest_approach.cd_utc}</p>
                        {fact.closest_approach.v_rel_km_s && (
                          <p>Relative Velocity: {fact.closest_approach.v_rel_km_s.toFixed(1)} km/s</p>
                        )}
                      </div>
                    )}
                    
                    {fact.error && (
                      <p className="text-sm text-red-600 dark:text-red-400">
                        Error: {fact.error}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Object Details */}
          {objectData && (
            <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-purple-600" />
                  <h4 className="font-medium text-gray-800 dark:text-white">Object Details</h4>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getThreatLevelColor(objectData.threat_level)}`}>
                  {objectData.threat_level.toUpperCase()} THREAT
                </span>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Designation:</span>
                  <span className="font-medium text-gray-800 dark:text-white">{objectData.designation}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Full Name:</span>
                  <span className="font-medium text-gray-800 dark:text-white">{objectData.fullname}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Close Approaches:</span>
                  <span className="font-medium text-gray-800 dark:text-white">{objectData.close_approaches.length}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Data Sources */}
      <div className="mt-6 bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
        <h4 className="font-medium text-gray-800 dark:text-white mb-3">Authoritative Data Sources</h4>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <a 
            href="https://ssd-api.jpl.nasa.gov/doc/sbdb.html" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-700"
          >
            <ExternalLink className="w-4 h-4" />
            <span>JPL Small-Body Database</span>
          </a>
          <a 
            href="https://ssd-api.jpl.nasa.gov/doc/cad.html" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-700"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Close-Approach Data</span>
          </a>
          <a 
            href="https://www.nasa.gov/solar-system/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-700"
          >
            <ExternalLink className="w-4 h-4" />
            <span>NASA Solar System</span>
          </a>
          <a 
            href="https://science.nasa.gov/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-700"
          >
            <ExternalLink className="w-4 h-4" />
            <span>NASA Science</span>
          </a>
        </div>
      </div>
    </div>
  );
}