import { useState, useEffect, useCallback } from 'react';
import { musicService, Track, Playlist, MusicPlayerState } from '../services/musicService';
import { GeneratedTrack, MusicGenerationOptions } from '../services/musicGenerationService';

export function useMusic() {
  const [playerState, setPlayerState] = useState<MusicPlayerState>(musicService.getState());
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [searchResults, setSearchResults] = useState<Track[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [aiRecommendations, setAiRecommendations] = useState<Track[]>([]);
  const [streamingServices, setStreamingServices] = useState(musicService.getStreamingServices());
  const [generatedTracks, setGeneratedTracks] = useState<GeneratedTrack[]>([]);
  const [isGeneratingMusic, setIsGeneratingMusic] = useState(false);

  useEffect(() => {
    // Load initial playlists
    setPlaylists(musicService.getCodingPlaylists());

    // Set up event listeners
    const handleStateChange = () => {
      setPlayerState(musicService.getState());
    };

    const handlePlaylistsLoaded = (loadedPlaylists: Playlist[]) => {
      setPlaylists(loadedPlaylists);
    };

    const handleServiceConnected = (service: any) => {
      setStreamingServices(prev => 
        prev.map(s => s.id === service.id ? { ...s, connected: true } : s)
      );
    };

    const handleAIRecommendation = (data: any) => {
      setAiRecommendations(data.tracks);
    };

    // Register listeners
    musicService.on('playback-started', handleStateChange);
    musicService.on('playback-paused', handleStateChange);
    musicService.on('playback-stopped', handleStateChange);
    musicService.on('track-changed', handleStateChange);
    musicService.on('volume-changed', handleStateChange);
    musicService.on('shuffle-changed', handleStateChange);
    musicService.on('repeat-changed', handleStateChange);
    musicService.on('playlists-loaded', handlePlaylistsLoaded);
    musicService.on('service-connected', handleServiceConnected);
    musicService.on('ai-recommendation', handleAIRecommendation);

    return () => {
      musicService.off('playback-started', handleStateChange);
      musicService.off('playback-paused', handleStateChange);
      musicService.off('playback-stopped', handleStateChange);
      musicService.off('track-changed', handleStateChange);
      musicService.off('volume-changed', handleStateChange);
      musicService.off('shuffle-changed', handleStateChange);
      musicService.off('repeat-changed', handleStateChange);
      musicService.off('playlists-loaded', handlePlaylistsLoaded);
      musicService.off('service-connected', handleServiceConnected);
      musicService.off('ai-recommendation', handleAIRecommendation);
    };
  }, []);

  const play = useCallback(async (track?: Track) => {
    if (track) {
      await musicService.play(track);
    } else {
      await musicService.play();
    }
  }, []);

  const pause = useCallback(() => {
    musicService.pause();
  }, []);

  const stop = useCallback(() => {
    musicService.stop();
  }, []);

  const next = useCallback(() => {
    musicService.next();
  }, []);

  const previous = useCallback(() => {
    musicService.previous();
  }, []);

  const setVolume = useCallback((volume: number) => {
    musicService.setVolume(volume);
  }, []);

  const seek = useCallback((time: number) => {
    musicService.seek(time);
  }, []);

  const toggleShuffle = useCallback(() => {
    musicService.toggleShuffle();
  }, []);

  const toggleRepeat = useCallback(() => {
    musicService.toggleRepeat();
  }, []);

  const generateAIMusic = useCallback(async (options: MusicGenerationOptions) => {
    setIsGeneratingMusic(true);
    try {
      const track = await musicService.generateAIMusic(options);
      setGeneratedTracks(prev => [...prev, track]);
    } catch (error) {
      console.error('AI music generation failed:', error);
      throw error;
    } finally {
      setIsGeneratingMusic(false);
    }
  }, []);

  const generateAdaptiveMusic = useCallback(async (currentCode: string, language: string, complexity: number) => {
    setIsGeneratingMusic(true);
    try {
      const { musicGenerationService } = await import('../services/musicGenerationService');
      const track = await musicGenerationService.generateAdaptiveTrack(currentCode, language, complexity);
      setGeneratedTracks(prev => [...prev, track]);
      
      // Automatically play the generated track
      await play({
        id: track.id,
        title: track.title,
        artist: track.artist,
        album: 'AI Generated',
        duration: track.duration,
        url: track.audioUrl,
        genre: track.genre,
        isLocal: true
      });
      return track;
    } catch (error) {
      console.error('Adaptive music generation failed:', error);
      throw error;
    } finally {
      setIsGeneratingMusic(false);
    }
  }, [play]);

  const generateCodingPlaylist = useCallback(async (scenario: 'deep-focus' | 'debugging' | 'creative' | 'learning') => {
    setIsGeneratingMusic(true);
    try {
      const { musicGenerationService } = await import('../services/musicGenerationService');
      const tracks = await musicGenerationService.generateCodingPlaylist(scenario);
      setGeneratedTracks(prev => [...prev, ...tracks]);
      
      // Create a playlist from generated tracks
      const playlist: Playlist = {
        id: `generated-${scenario}-${Date.now()}`,
        name: `AI Generated: ${scenario.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}`,
        description: `AI-generated music optimized for ${scenario} coding sessions`,
        tracks: tracks.map(track => ({
          id: track.id,
          title: track.title,
          artist: track.artist,
          album: 'AI Generated',
          duration: track.duration,
          url: track.audioUrl,
          genre: track.genre,
          isLocal: true
        })),
        isPublic: false,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      setPlaylists(prev => [...prev, playlist]);
      return tracks;
    } catch (error) {
      console.error('Coding playlist generation failed:', error);
      throw error;
    } finally {
      setIsGeneratingMusic(false);
    }
  }, []);

  const clearGeneratedMusic = useCallback(() => {
    musicService.clearGeneratedTracks();
    setGeneratedTracks([]);
  }, []);

  const playPlaylist = useCallback((playlist: Playlist) => {
    musicService.playPlaylist(playlist);
  }, []);

  const searchTracks = useCallback(async (query: string, service?: string) => {
    setIsLoading(true);
    try {
      const results = await musicService.searchTracks(query, service);
      setSearchResults(results);
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const connectStreamingService = useCallback(async (service: string, credentials?: any) => {
    setIsLoading(true);
    try {
      const success = await musicService.connectStreamingService(service, credentials);
      return success;
    } catch (error) {
      console.error('Service connection failed:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const getAIRecommendations = useCallback(async (codeContext: {
    language: string;
    complexity: number;
    timeOfDay: string;
    mood?: string;
  }) => {
    setIsLoading(true);
    try {
      const recommendations = await musicService.getAIRecommendations(codeContext);
      setAiRecommendations(recommendations);
      return recommendations;
    } catch (error) {
      console.error('AI recommendations failed:', error);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createPlaylist = useCallback((name: string, description: string = '') => {
    return musicService.createPlaylist(name, description);
  }, []);

  const addToPlaylist = useCallback((playlistId: string, track: Track) => {
    musicService.addToPlaylist(playlistId, track);
  }, []);

  const downloadTrack = useCallback(async (track: Track) => {
    setIsLoading(true);
    try {
      const success = await musicService.downloadTrack(track);
      return success;
    } catch (error) {
      console.error('Download failed:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const formatTime = useCallback((seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }, []);

  return {
    // State
    playerState,
    playlists,
    searchResults,
    isLoading,
    aiRecommendations,
    streamingServices,
    generatedTracks,
    isGeneratingMusic,
    
    // Playback controls
    play,
    pause,
    stop,
    next,
    previous,
    setVolume,
    seek,
    toggleShuffle,
    toggleRepeat,
    
    // Playlist management
    playPlaylist,
    createPlaylist,
    addToPlaylist,
    
    // Search and discovery
    searchTracks,
    getAIRecommendations,
    generateAIMusic,
    generateAdaptiveMusic,
    generateCodingPlaylist,
    clearGeneratedMusic,
    
    // Streaming services
    connectStreamingService,
    
    // Offline support
    downloadTrack,
    
    // Utilities
    formatTime
  };
}
