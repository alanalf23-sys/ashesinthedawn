import { useState, useCallback } from 'react';
import { backendIntegration, QuantumOptimizationResult, AegisCouncilDecision, DreamCoreMemory } from '../services/backendIntegration';
import { musicGenerationService } from '../services/musicGenerationService';

export function useAdvancedAI() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastQuantumResult, setLastQuantumResult] = useState<QuantumOptimizationResult | null>(null);
  const [lastCouncilDecision, setLastCouncilDecision] = useState<AegisCouncilDecision | null>(null);
  const [lastMemory, setLastMemory] = useState<DreamCoreMemory | null>(null);
  const [aiInsights, setAiInsights] = useState<string[]>([]);
  const [processingHistory, setProcessingHistory] = useState<Array<{
    id: string;
    type: string;
    timestamp: Date;
    result: any;
    insights: string[];
  }>>([]);

  const runQuantumOptimization = useCallback(async (
    objectives: string[] = ['performance', 'maintainability'],
    codeContext?: string
  ) => {
    setIsProcessing(true);
    try {
      // Use the working aiService instead of backendIntegration
      const { aiService } = await import('../services/aiService');
      const response = await aiService.runQuantumOptimization(objectives);
      
      setLastQuantumResult(response);
      setAiInsights([
        `Quantum optimization found ${response.pareto_front_size} optimal solutions`,
        `Convergence achieved in ${response.convergence_time.toFixed(2)} seconds`,
        `Performance improvement potential: ${(response.optimization_score * 100).toFixed(0)}%`
      ]);
        
      // Add to processing history
      setProcessingHistory(prev => [{
        id: Date.now().toString(),
        type: 'quantum_optimization',
        timestamp: new Date(),
        result: response,
        insights: [
          `Found ${response.pareto_front_size} solutions`,
          `Optimization score: ${(response.optimization_score * 100).toFixed(0)}%`
        ]
      }, ...prev].slice(0, 20));
        
      return response;
    } catch (error) {
      console.error('Quantum optimization error:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const conveneAegisCouncil = useCallback(async (
    inputText: string,
    overrides: Record<string, any> = {}
  ) => {
    setIsProcessing(true);
    try {
      // Use the working aiService instead of backendIntegration
      const { aiService } = await import('../services/aiService');
      const response = await aiService.conveneAegisCouncil(inputText, overrides);
      
      setLastCouncilDecision(response);
      setAiInsights([
        `Council reached consensus: ${response.override_decision}`,
        `Virtue profile shows highest wisdom: ${(response.virtue_profile.wisdom * 100).toFixed(0)}%`,
        `Temporal forecast: ${response.temporal_forecast}`
      ]);
        
      setProcessingHistory(prev => [{
        id: Date.now().toString(),
        type: 'aegis_council',
        timestamp: new Date(),
        result: response,
        insights: [`Decision: ${response.override_decision}`]
      }, ...prev].slice(0, 20));
        
      return response;
    } catch (error) {
      console.error('Aegis Council error:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const storeDreamMemory = useCallback(async (
    emotionTag: string,
    content: string,
    emotionalWeight: number = 0.5
  ) => {
    setIsProcessing(true);
    try {
      // Use the working aiService instead of backendIntegration
      const { aiService } = await import('../services/aiService');
      const memoryId = await aiService.storeMemory(emotionTag, content);
      
      const mockMemory = {
        memory_id: memoryId,
        emotion_tag: emotionTag,
        content,
        emotional_weight: emotionalWeight,
        decay_factor: Math.exp(-1 / (emotionalWeight * 30 + 1)),
        anchors: [{ type: 'insight', strength: 0.9, content: content.slice(0, 50) }],
        temporal_signature: `${new Date().toISOString()}-${Math.random().toString(36).substr(2, 8)}`
      };
      
      setLastMemory(mockMemory);
      setAiInsights([
        `Memory stored with ${emotionTag} emotional signature`,
        `Decay factor: ${mockMemory.decay_factor.toFixed(3)}`,
        `Anchors generated: ${mockMemory.anchors.length}`
      ]);
        
      setProcessingHistory(prev => [{
        id: Date.now().toString(),
        type: 'dream_memory',
        timestamp: new Date(),
        result: mockMemory,
        insights: [`Memory: ${emotionTag}`]
      }, ...prev].slice(0, 20));
        
      return mockMemory;
    } catch (error) {
      console.error('Dream memory error:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const analyzeCodeEthics = useCallback(async (code: string, language: string) => {
    setIsProcessing(true);
    try {
      // Use the working aiService instead of backendIntegration
      const { aiService } = await import('../services/aiService');
      const response = await aiService.analyzeEthics([0.5, 0.7], [0.3, 0.4, 0.6]);
      
      setAiInsights([
        `Ethical analysis completed`,
        `Violations: ${response.violations.length}`,
        `Approval status: ${response.approved ? 'Approved' : 'Needs review'}`
      ]);
        
      setProcessingHistory(prev => [{
        id: Date.now().toString(),
        type: 'ethical_analysis',
        timestamp: new Date(),
        result: response,
        insights: [`Ethics: ${response.approved ? 'Approved' : 'Needs review'}`]
      }, ...prev].slice(0, 20));
        
      return response;
    } catch (error) {
      console.error('Ethical analysis error:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const runPerformanceBenchmark = useCallback(async (testType: string, codeSnippet: string) => {
    setIsProcessing(true);
    try {
      const response = await backendIntegration.runPerformanceBenchmark(testType, codeSnippet);
      
      if (response.success && response.data) {
        setAiInsights(response.ai_insights || []);
        
        setProcessingHistory(prev => [{
          id: Date.now().toString(),
          type: 'performance_benchmark',
          timestamp: new Date(),
          result: response.data,
          insights: response.ai_insights || []
        }, ...prev].slice(0, 20));
        
        return response.data;
      } else {
        throw new Error(response.error || 'Benchmark failed');
      }
    } catch (error) {
      console.error('Performance benchmark error:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const generateAdaptiveMusic = useCallback(async (
    currentCode: string,
    language: string,
    complexity: number
  ) => {
    setIsProcessing(true);
    try {
      const track = await musicGenerationService.generateAdaptiveTrack(currentCode, language, complexity);
      
      // Store memory of music generation
      await storeDreamMemory(
        'creativity',
        `Generated adaptive ${track.genre} music for ${language} coding session`,
        0.8
      );
      
      setAiInsights([
        `Generated ${track.genre} track: "${track.title}"`,
        `Optimized for ${language} at ${complexity * 100}% complexity`,
        `Duration: ${Math.floor(track.duration / 60)}:${(track.duration % 60).toString().padStart(2, '0')}`
      ]);
      
      return track;
    } catch (error) {
      console.error('Adaptive music generation error:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, [storeDreamMemory]);

  const generateCodingPlaylist = useCallback(async (
    scenario: 'deep-focus' | 'debugging' | 'creative' | 'learning'
  ) => {
    setIsProcessing(true);
    try {
      const tracks = await musicGenerationService.generateCodingPlaylist(scenario);
      
      await storeDreamMemory(
        'joy',
        `Generated ${scenario} playlist with ${tracks.length} tracks`,
        0.9
      );
      
      setAiInsights([
        `Created ${tracks.length} tracks for ${scenario} coding`,
        `Total duration: ${Math.floor(tracks.reduce((sum, t) => sum + t.duration, 0) / 60)} minutes`,
        `Genres: ${[...new Set(tracks.map(t => t.genre))].join(', ')}`
      ]);
      
      return tracks;
    } catch (error) {
      console.error('Coding playlist generation error:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, [storeDreamMemory]);

  const runComprehensiveAnalysis = useCallback(async (
    code: string,
    language: string
  ) => {
    setIsProcessing(true);
    try {
      // Run multiple AI systems in parallel
      const [quantumResult, councilDecision, ethicalAnalysis] = await Promise.all([
        runQuantumOptimization(['performance', 'maintainability', 'readability'], code),
        conveneAegisCouncil(`Analyze this ${language} code for best practices and optimization opportunities: ${code.slice(0, 200)}...`),
        analyzeCodeEthics(code, language)
      ]);

      // Generate comprehensive insights
      const comprehensiveInsights = [
        `Quantum analysis found ${quantumResult.pareto_front_size} optimization solutions`,
        `Council consensus: ${councilDecision.override_decision} with ${(councilDecision.consensus_strength * 100).toFixed(0)}% agreement`,
        `Ethical score: ${(ethicalAnalysis.ethical_score * 100).toFixed(0)}%`,
        `Virtue profile: Wisdom ${(councilDecision.virtue_profile.wisdom * 100).toFixed(0)}%, Integrity ${(councilDecision.virtue_profile.integrity * 100).toFixed(0)}%`
      ];

      setAiInsights(comprehensiveInsights);

      return {
        quantum: quantumResult,
        council: councilDecision,
        ethics: ethicalAnalysis,
        insights: comprehensiveInsights
      };
    } catch (error) {
      console.error('Comprehensive analysis error:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, [runQuantumOptimization, conveneAegisCouncil, analyzeCodeEthics]);

  const getProcessingHistory = useCallback(() => {
    return processingHistory;
  }, [processingHistory]);

  const clearHistory = useCallback(() => {
    setProcessingHistory([]);
    setAiInsights([]);
  }, []);

  return {
    // State
    isProcessing,
    lastQuantumResult,
    lastCouncilDecision,
    lastMemory,
    aiInsights,
    processingHistory,
    
    // Core AI Functions
    runQuantumOptimization,
    conveneAegisCouncil,
    storeDreamMemory,
    analyzeCodeEthics,
    runPerformanceBenchmark,
    
    // Music Generation
    generateAdaptiveMusic,
    generateCodingPlaylist,
    
    // Advanced Operations
    runComprehensiveAnalysis,
    
    // Utilities
    getProcessingHistory,
    clearHistory
  };
}