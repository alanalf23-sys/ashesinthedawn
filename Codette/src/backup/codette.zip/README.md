# Codette

A neuro-symbolic assistant AI with modular architecture and creativity.