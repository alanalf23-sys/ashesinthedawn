
import os
from setuptools import setup, find_packages

setup(
    name='codette',
    version='0.1.0',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'numpy',
        'matplotlib',
        'networkx',
        'transformers',
        'scikit-learn',
        'requests'
    ],
    author='Jonathan Harrison',
    description='Codette: Neuro-symbolic creative assistant AI',
    long_description=open('README.md').read() if os.path.exists('README.md') else '',
    long_description_content_type='text/markdown',
    url='https://www.kaggle.com/models/jonathanharrison1/codette2',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
)
