/*
  # Add storage and database policies for file uploads

  1. Changes
    - Add storage bucket policies for authenticated users
    - Update RLS policies for codette_files table
    - Add admin-only upload policy

  2. Security
    - Enable RLS on codette_files table
    - Add policies for authenticated users to read files
    - Add policy for admin users to upload files
    - Add storage bucket policies
*/

-- First, ensure the storage.objects policy exists for the codette-files bucket
BEGIN;

-- Create policy to allow authenticated users to read any file
CREATE POLICY "Allow authenticated users to read files"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'codette-files');

-- Create policy to allow only admin users to upload files
CREATE POLICY "Allow admin users to upload files"
ON storage.objects FOR INSERT
TO authenticated
USING (bucket_id = 'codette-files' AND auth.jwt() ->> 'role' = 'admin');

-- Update the codette_files table policies
CREATE POLICY "Allow admin users to insert files"
ON public.codette_files FOR INSERT
TO authenticated
WITH CHECK (auth.jwt() ->> 'role' = 'admin');

COMMIT;