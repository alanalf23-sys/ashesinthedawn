-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow authenticated users to read files" ON public.codette_files;
DROP POLICY IF EXISTS "Allow authenticated users to insert files" ON public.codette_files;

-- Create or update the codette_files table
CREATE TABLE IF NOT EXISTS public.codette_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  filename text NOT NULL,
  storage_path text NOT NULL,
  file_type text,
  uploaded_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.codette_files ENABLE ROW LEVEL SECURITY;

-- Create new policies
CREATE POLICY "Allow authenticated users to read files"
  ON public.codette_files
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert files"
  ON public.codette_files
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create user_cognitive_fingerprints table
CREATE TABLE IF NOT EXISTS public.user_cognitive_fingerprints (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  active_perspectives jsonb DEFAULT '[]'::jsonb,
  recursion_depth integer DEFAULT 3,
  ethical_score float DEFAULT 0.8,
  processing_power float DEFAULT 0.7,
  quantum_state jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT recursion_depth_range CHECK (recursion_depth BETWEEN 1 AND 5),
  CONSTRAINT ethical_score_range CHECK (ethical_score BETWEEN 0 AND 1),
  CONSTRAINT processing_power_range CHECK (processing_power BETWEEN 0 AND 1)
);

-- Enable RLS on user_cognitive_fingerprints
ALTER TABLE public.user_cognitive_fingerprints ENABLE ROW LEVEL SECURITY;

-- Create policies for user_cognitive_fingerprints
CREATE POLICY "Users can read their own fingerprints"
  ON public.user_cognitive_fingerprints
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update their own fingerprints"
  ON public.user_cognitive_fingerprints
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can insert their own fingerprints"
  ON public.user_cognitive_fingerprints
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());