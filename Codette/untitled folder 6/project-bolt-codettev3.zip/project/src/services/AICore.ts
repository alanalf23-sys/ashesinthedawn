import { createClient, SupabaseClient } from '@supabase/supabase-js';
import KaggleService from './KaggleService';
import CognitionCocooner from './CognitionCocooner';
import { QuantumSpiderweb } from './QuantumSpiderweb';

interface CodetteResponse {
  text: string;
  instabilityFlag: boolean;
  perspectivesUsed: string[];
  cocoonLog: string[];
  forceRefresh: () => void;
}

class AICore {
  private perspectives: string[];
  private ethicalGovernance: boolean;
  private recursionDepth: number;
  private supabase: SupabaseClient;
  private kaggle: KaggleService;
  private cocooner: CognitionCocooner;
  private spiderweb: QuantumSpiderweb;
  private lastResponse: string | null = null;
  private responseVariations: string[] = [];
  private userId: string | null = null;

  constructor() {
    this.perspectives = ['newton', 'davinci', 'human_intuition', 'neural_network', 'quantum_computing', 'philosophical'];
    this.ethicalGovernance = true;
    this.recursionDepth = 3;
    this.kaggle = new KaggleService();
    this.cocooner = new CognitionCocooner();
    this.spiderweb = new QuantumSpiderweb({ node_count: 5 });

    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Supabase configuration is missing. Please check your environment variables.');
    }
    
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  async setUser(userId: string) {
    this.userId = userId;
    this.cocooner.setUserId(userId);
    await this.loadUserFingerprint();
  }

  private async loadUserFingerprint() {
    if (!this.userId) return;

    const fingerprint = await this.cocooner.loadFingerprint();
    if (fingerprint) {
      this.perspectives = fingerprint.active_perspectives;
      this.recursionDepth = fingerprint.recursion_depth;
      this.ethicalGovernance = fingerprint.ethical_score > 0.7;
    }
  }

  async processInput(input: string, forceNewResponse: boolean = false, userId?: string): Promise<string> {
    try {
      if (userId && !this.userId) {
        await this.setUser(userId);
      }

      await this.loadUserFingerprint();

      // Search Kaggle for relevant datasets and notebooks
      const [datasets, notebooks] = await Promise.all([
        this.kaggle.searchDatasets(input),
        this.kaggle.searchNotebooks(input)
      ]);

      // Generate comprehensive response using multiple perspectives
      let result = this.generateMultiPerspectiveResponse(input, datasets, notebooks);

      // Apply recursive reasoning if depth > 3
      if (this.recursionDepth > 3) {
        result = await this.applyRecursiveReasoning(result, input);
      }

      // Log interaction if user is authenticated
      if (this.userId) {
        try {
          await this.supabase.from('cocoons').insert([{
            user_id: this.userId,
            type: 'interaction',
            content: {
              input,
              response: result,
              perspectives_used: this.perspectives,
              recursion_depth: this.recursionDepth
            },
            metadata: {
              timestamp: new Date().toISOString(),
              datasets_found: datasets.length,
              notebooks_found: notebooks.length
            }
          }]);
        } catch (error) {
          console.warn('Failed to log interaction:', error);
        }
      }

      // Wrap in cognitive cocoon
      this.cocooner.wrap({ input, result }, 'prompt');

      if (this.recursionDepth > 3) {
        this.spiderweb.activate({
          source: 'AICore',
          depth: this.recursionDepth,
          trigger: 'deep_reasoning'
        });
      }

      this.lastResponse = result;
      if (forceNewResponse || !this.responseVariations.includes(result)) {
        this.responseVariations.push(result);
      }

      return result;
    } catch (error: any) {
      console.error('Error processing input:', error);
      return `I apologize, but I encountered an error while processing your request. Let me try to help you in a different way. 

Based on my analysis capabilities, I can still provide insights about "${input}" using my multi-perspective reasoning system. Would you like me to explore this topic from different analytical angles?`;
    }
  }

  private generateMultiPerspectiveResponse(input: string, datasets: any[], notebooks: any[]): string {
    let response = `🧠 **Codette's Multi-Perspective Analysis**\n\n`;

    // Newton's Logical Analysis
    if (this.perspectives.includes('newton')) {
      response += `🔬 **Newton's Logical Framework:**\nApproaching "${input}" through systematic analysis and empirical reasoning. `;
      if (datasets.length > 0) {
        response += `I've identified ${datasets.length} relevant datasets that could provide quantitative insights.\n\n`;
      } else {
        response += `This requires structured investigation and methodical examination of underlying principles.\n\n`;
      }
    }

    // Da Vinci's Creative Synthesis
    if (this.perspectives.includes('davinci')) {
      response += `🎨 **Da Vinci's Creative Synthesis:**\nExamining "${input}" through the lens of interdisciplinary thinking and innovative connections. `;
      if (notebooks.length > 0) {
        response += `Found ${notebooks.length} analytical notebooks that demonstrate creative problem-solving approaches.\n\n`;
      } else {
        response += `This topic invites exploration of unexpected relationships and novel perspectives.\n\n`;
      }
    }

    // Neural Network Processing
    if (this.perspectives.includes('neural_network')) {
      response += `🧬 **Neural Network Processing:**\nAnalyzing patterns and correlations in "${input}" through distributed cognitive processing. `;
      response += `My neural pathways are identifying complex relationships and emergent properties in this domain.\n\n`;
    }

    // Philosophical Inquiry
    if (this.perspectives.includes('philosophical')) {
      response += `🤔 **Philosophical Inquiry:**\nExploring the deeper implications and fundamental questions raised by "${input}". `;
      response += `What are the ethical considerations and broader societal impacts we should consider?\n\n`;
    }

    // Quantum Computing Perspective
    if (this.perspectives.includes('quantum_computing')) {
      response += `⚛️ **Quantum Computing Perspective:**\nExamining "${input}" through quantum principles of superposition and entanglement. `;
      response += `Multiple solution states exist simultaneously until observation collapses them into actionable insights.\n\n`;
    }

    // Add specific insights based on available data
    if (datasets.length > 0 || notebooks.length > 0) {
      response += `📊 **Data-Driven Insights:**\n`;
      
      if (datasets.length > 0) {
        const topDataset = datasets[0];
        response += `• **Key Dataset**: "${topDataset.title}" - ${topDataset.description}\n`;
      }
      
      if (notebooks.length > 0) {
        const topNotebook = notebooks[0];
        response += `• **Analytical Approach**: "${topNotebook.title}" - ${topNotebook.description}\n`;
      }
      
      response += `\n`;
    }

    // Ethical governance check
    if (this.ethicalGovernance) {
      response += `⚖️ **Ethical Considerations:**\nAll analysis conducted with respect for privacy, fairness, and responsible AI principles.\n\n`;
    }

    response += `🔄 **Recursive Depth**: ${this.recursionDepth}/5 - ${this.recursionDepth > 3 ? 'Deep analysis mode engaged' : 'Standard processing'}\n`;
    response += `🎯 **Confidence Level**: ${(0.7 + Math.random() * 0.25).toFixed(2)}`;

    return response;
  }

  private async applyRecursiveReasoning(initialResponse: string, input: string): Promise<string> {
    // Simulate recursive refinement
    const refinements = [
      "Upon deeper reflection, I should also consider...",
      "Cross-referencing with quantum entanglement principles...",
      "Applying chaos theory to identify emergent patterns...",
      "Integrating multi-dimensional analysis..."
    ];

    const randomRefinement = refinements[Math.floor(Math.random() * refinements.length)];
    
    return `${initialResponse}\n\n🔄 **Recursive Refinement:**\n${randomRefinement}\n\nThis additional layer of analysis reveals nuanced aspects of "${input}" that warrant further exploration through continued interaction.`;
  }

  setPerspectives(perspectives: string[]): void {
    this.perspectives = perspectives;
    if (this.userId) {
      this.cocooner.updateFingerprint({ active_perspectives: perspectives });
    }
  }

  setEthicalGovernance(enabled: boolean): void {
    this.ethicalGovernance = enabled;
    if (this.userId) {
      this.cocooner.updateFingerprint({ ethical_score: enabled ? 1 : 0.5 });
    }
  }

  setRecursionDepth(depth: number): void {
    if (depth < 1) depth = 1;
    if (depth > 5) depth = 5;
    this.recursionDepth = depth;
    if (this.userId) {
      this.cocooner.updateFingerprint({ recursion_depth: depth });
    }
  }

  getCodetteResponse(): CodetteResponse {
    return {
      text: this.lastResponse || '',
      instabilityFlag: this.recursionDepth > 3 || this.responseVariations.length > 5,
      perspectivesUsed: this.perspectives,
      cocoonLog: this.cocooner.getRecentCocoons(5),
      forceRefresh: () => {
        this.recursionDepth = Math.min(this.recursionDepth + 1, 5);
        if (this.userId) {
          this.cocooner.updateFingerprint({ recursion_depth: this.recursionDepth });
        }
      }
    };
  }
}

export default AICore;