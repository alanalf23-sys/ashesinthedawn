/*
  # Create codette_files table and policies

  1. Changes
    - Create codette_files table if it doesn't exist
    - Enable RLS
    - Add policies for file access
  
  2. Security
    - Check for existing policies before creating them
    - Allow authenticated users to read and insert files
*/

-- Create table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.codette_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  filename text NOT NULL,
  storage_path text NOT NULL,
  file_type text,
  uploaded_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.codette_files ENABLE ROW LEVEL SECURITY;

-- Create policies with existence checks
DO $$
BEGIN
    -- Check if read policy exists before creating
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'codette_files' 
        AND policyname = 'Allow authenticated users to read files'
    ) THEN
        CREATE POLICY "Allow authenticated users to read files"
        ON public.codette_files
        FOR SELECT
        TO authenticated
        USING (true);
    END IF;

    -- Check if insert policy exists before creating
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'codette_files' 
        AND policyname = 'Allow authenticated users to insert files'
    ) THEN
        CREATE POLICY "Allow authenticated users to insert files"
        ON public.codette_files
        FOR INSERT
        TO authenticated
        WITH CHECK (true);
    END IF;
END $$;