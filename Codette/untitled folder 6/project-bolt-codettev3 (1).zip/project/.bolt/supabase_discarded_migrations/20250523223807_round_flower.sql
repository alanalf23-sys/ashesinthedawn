/*
  # Fix Admin Authentication

  1. Changes
    - Create admin role
    - Set up authentication policies
    - Add admin user

  2. Security
    - Enable RLS
    - Add policies for admin access
*/

-- Create admin role if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_roles WHERE rolname = 'admin'
  ) THEN
    CREATE ROLE admin;
  END IF;
END $$;

-- Create auth schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS auth;

-- Enable RLS on auth tables
ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

-- Create policy for admin users
CREATE POLICY "Allow admin users full access"
ON auth.users
TO admin
USING (true)
WITH CHECK (true);

-- Insert admin user if not exists
INSERT INTO auth.users (
  email,
  encrypted_password,
  role,
  email_confirmed_at,
  created_at,
  updated_at
)
VALUES (
  'admin@codette.ai',
  crypt('admin123', gen_salt('bf')),
  'admin',
  now(),
  now(),
  now()
)
ON CONFLICT (email) DO NOTHING;