/*
  # Fix Storage Policies and RLS

  1. New Approach
    - Use proper storage policy creation syntax
    - Check for existing policies before creating them
    - Enable RLS on codette_files table if not already enabled
  
  2. Security
    - Add policies for storage objects in the codette-files bucket
    - Ensure authenticated users can read files
    - Allow admin users to upload files
    - Add policies for the codette_files table
*/

-- First, enable RLS on the codette_files table if not already enabled
DO $$
BEGIN
    -- Check if RLS is already enabled
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables 
        WHERE tablename = 'codette_files' 
        AND rowsecurity = true
    ) THEN
        ALTER TABLE public.codette_files ENABLE ROW LEVEL SECURITY;
    END IF;
END $$;

-- Create storage bucket if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM storage.buckets WHERE name = 'codette-files'
    ) THEN
        INSERT INTO storage.buckets (id, name)
        VALUES ('codette-files', 'codette-files');
    END IF;
END $$;

-- Create storage policies for the codette-files bucket
DO $$
BEGIN
    -- Check if the read policy exists
    IF NOT EXISTS (
        SELECT 1 FROM storage.policies 
        WHERE name = 'Allow authenticated users to read files'
        AND bucket_id = 'codette-files'
    ) THEN
        -- Create policy for reading files
        INSERT INTO storage.policies (name, bucket_id, definition)
        VALUES (
            'Allow authenticated users to read files',
            'codette-files',
            '(auth.role() = ''authenticated'')'
        );
    END IF;

    -- Check if the upload policy exists
    IF NOT EXISTS (
        SELECT 1 FROM storage.policies 
        WHERE name = 'Allow admin users to upload files'
        AND bucket_id = 'codette-files'
    ) THEN
        -- Create policy for uploading files
        INSERT INTO storage.policies (name, bucket_id, definition)
        VALUES (
            'Allow admin users to upload files',
            'codette-files',
            '(auth.role() = ''authenticated'' AND (auth.jwt() ->> ''role'')::text = ''admin'')'
        );
    END IF;
END $$;

-- Create policies for the codette_files table
DO $$
BEGIN
    -- Check if the read policy exists
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE policyname = 'Allow authenticated users to read files'
        AND tablename = 'codette_files'
    ) THEN
        CREATE POLICY "Allow authenticated users to read files"
        ON public.codette_files FOR SELECT
        TO authenticated
        USING (true);
    END IF;

    -- Check if the admin insert policy exists
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE policyname = 'Allow admin users to insert files'
        AND tablename = 'codette_files'
    ) THEN
        CREATE POLICY "Allow admin users to insert files"
        ON public.codette_files FOR INSERT
        TO authenticated
        WITH CHECK (auth.jwt() ->> 'role' = 'admin');
    END IF;

    -- Check if the authenticated insert policy exists
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE policyname = 'Allow authenticated users to insert files'
        AND tablename = 'codette_files'
    ) THEN
        CREATE POLICY "Allow authenticated users to insert files"
        ON public.codette_files FOR INSERT
        TO authenticated
        WITH CHECK (true);
    END IF;
END $$;