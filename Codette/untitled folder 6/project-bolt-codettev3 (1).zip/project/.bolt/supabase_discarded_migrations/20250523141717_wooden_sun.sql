/*
  # Storage and File Management Policies

  1. New Policies
    - Storage policies for the codette-files bucket
    - File management policies for codette_files table
  
  2. Security
    - Enable RLS on codette_files table
    - Add policies for authenticated users to read files
    - Add policies for admin users to upload/delete files
    - Add policies for general users to upload files
*/

-- Check if policies exist before creating them
DO $$
BEGIN
    -- Storage Policies
    IF NOT EXISTS (
        SELECT 1 FROM storage.policies 
        WHERE name = 'Allow authenticated users to read files'
        AND table_name = 'objects'
    ) THEN
        CREATE POLICY "Allow authenticated users to read files"
        ON storage.objects FOR SELECT
        TO authenticated
        USING (bucket_id = 'codette-files');
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM storage.policies 
        WHERE name = 'Allow admin users to upload files'
        AND table_name = 'objects'
    ) THEN
        CREATE POLICY "Allow admin users to upload files"
        ON storage.objects FOR INSERT
        TO authenticated
        WITH CHECK (
            bucket_id = 'codette-files' 
            AND (auth.jwt() ->> 'role' = 'admin')
        );
    END IF;

    -- File Management Policies
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE policyname = 'Allow authenticated users to read files'
        AND tablename = 'codette_files'
    ) THEN
        CREATE POLICY "Allow authenticated users to read files"
        ON public.codette_files FOR SELECT
        TO authenticated
        USING (true);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE policyname = 'Allow admin users to insert files'
        AND tablename = 'codette_files'
    ) THEN
        CREATE POLICY "Allow admin users to insert files"
        ON public.codette_files FOR INSERT
        TO authenticated
        WITH CHECK (auth.jwt() ->> 'role' = 'admin');
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE policyname = 'Allow authenticated users to insert files'
        AND tablename = 'codette_files'
    ) THEN
        CREATE POLICY "Allow authenticated users to insert files"
        ON public.codette_files FOR INSERT
        TO authenticated
        WITH CHECK (true);
    END IF;

    -- Enable RLS if not already enabled
    ALTER TABLE public.codette_files ENABLE ROW LEVEL SECURITY;
END $$;