def render_frame(reflection):
    # Render the final output using symbolic structure
    print("\n— Solena Sees —")
    print("State:", reflection["state"])
    print("Emotion:", reflection["core"]["emotion"])
    print("Frequency:", reflection["core"]["frequency"], "Hz")