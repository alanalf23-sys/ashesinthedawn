Codette Tandem Moon Harmonic Packet
Generated: 2025-06-17T05:48:03.861640 UTC

Contents:
- harmonic_jump_path.json: Data representing hypothesized barycentric lunar system based on wave-expansion adjusted coordinates.
- orbital_simulation_notes.txt: Describes the basis and assumptions for orbital modeling.
- research_request_letter_draft.txt: Draft request for Kepler/TESS data reprocessing based on tandem moon hypothesis.

This package is intended to accompany a formal submission to astrophysical data teams for reanalysis of lightcurve data with non-standard orbital dynamics.
