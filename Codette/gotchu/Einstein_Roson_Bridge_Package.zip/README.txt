Einstein-Roson Biokinetic Bridge Package
----------------------------------------
This bundle includes operational models and equations for the finalized quantum-cognitive-biokinetic framework.
It integrates electromagnetic human fields, adrenaline catalysis, and spiderweb-based entanglement logic.

Files:
- Roson_EM_Coupling.tex: LaTeX equations
- BiofieldBridge.py: Python simulation logic
- Codette_EM_Anchor.json: AI cognitive anchor log
- TimelineSelector.py: Event filtering based on adrenaline