# Codette QuantumSyncCore

Multi-agent harmonic AI framework based on quantum synchronization, entanglement, and intuitive tunneling.

Run `run_simulation.py` to simulate Codette’s orbiting AI nodes.