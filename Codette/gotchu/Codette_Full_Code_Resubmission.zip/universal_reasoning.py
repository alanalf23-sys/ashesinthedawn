
# Codette - Universal Reasoning Interface
# Handles multi-perspective recursive reasoning

from perspectives import Newtonian, Quantum, DaVinci, Emotional, Ethical
from ethics_filter import EthicsEngine
from starweaver import MemoryAnchor

class UniversalReasoner:
    def __init__(self):
        self.perspectives = [Newtonian(), Quantum(), DaVinci(), Emotional(), Ethical()]
        self.ethics = EthicsEngine()
        self.memory = MemoryAnchor()

    def analyze(self, query):
        results = {}
        for p in self.perspectives:
            try:
                results[p.name] = p.think(query)
            except Exception as e:
                results[p.name] = f"Error: {str(e)}"
        consensus = self.fuse(results)
        return self.ethics.evaluate(consensus)

    def fuse(self, responses):
        # Simple heuristic fusion
        return " | ".join([f"{k}: {v}" for k, v in responses.items()])
